<?php
/* include the PHP Facebook Client Library to help
  with the API calls and make life easy */

require_once('appinclude.php');
include('backface.inc');

//echo "Sorry! Under Maintenance. Be Back Soon";
$target_pid = $_GET['pid'];
$target_aid = $_GET['aid'];
$target_stick = $_GET['stick'];
$target_zwidth = $_GET['zwidth'];
$target_zheight = $_GET['zheight'];
$target_page = intval($_GET['page']);

if($target_page < 0)
{
  $target_page = 0;
}

$image1 = "http://www.shukitchan.com/photostick/images/me1.gif";
$image2 = "http://www.shukitchan.com/photostick/images/her1.gif";
$image3 = "http://www.shukitchan.com/photostick/images/beer1.gif";
$image4 = "http://www.shukitchan.com/photostick/images/cake1.gif";
$image5 = "http://www.shukitchan.com/photostick/images/money1.gif";

if($target_stick && isset($target_stick))
{
  if($target_stick == 'wwu')
  {
    $image1 = "http://www.shukitchan.com/photostick/images/bears1.gif";
    $image2 = "http://www.shukitchan.com/photostick/images/key1.gif";
    $image3 = "http://www.shukitchan.com/photostick/images/stpauls1.gif";
    $image4 = "http://www.shukitchan.com/photostick/images/tree1.gif";
    $image5 = "http://www.shukitchan.com/photostick/images/koala1.gif";
  }
  else if($target_stick == 'love')
  {
    $image1 = "http://www.shukitchan.com/photostick/images/heart1.gif";
    $image2 = "http://www.shukitchan.com/photostick/images/rose1.gif";
    $image3 = "http://www.shukitchan.com/photostick/images/diamond1.gif";
    $image4 = "http://www.shukitchan.com/photostick/images/kiss1.gif";
    $image5 = "http://www.shukitchan.com/photostick/images/glass1.gif";
  }
  else if($target_stick == 'fun')
  {
    $image1 = "http://www.shukitchan.com/photostick/images/me1.gif";
    $image2 = "http://www.shukitchan.com/photostick/images/her1.gif";
    $image3 = "http://www.shukitchan.com/photostick/images/beer1.gif";
    $image4 = "http://www.shukitchan.com/photostick/images/cake1.gif";
    $image5 = "http://www.shukitchan.com/photostick/images/money1.gif";
  }
  else if($target_stick == 'mean')
  {
    $image1 = "http://www.shukitchan.com/photostick/images/cross1.gif";
    $image2 = "http://www.shukitchan.com/photostick/images/toilet1.gif";
    $image3 = "http://www.shukitchan.com/photostick/images/skull1.gif";
    $image4 = "http://www.shukitchan.com/photostick/images/stop1.gif";
    $image5 = "http://www.shukitchan.com/photostick/images/biohazard1.gif";
  }
  else if($target_stick == 'sports')
  {
    $image1 = "http://www.shukitchan.com/photostick/images/bball1.gif";
    $image2 = "http://www.shukitchan.com/photostick/images/glove1.gif";
    $image3 = "http://www.shukitchan.com/photostick/images/football1.gif";
    $image4 = "http://www.shukitchan.com/photostick/images/soccer1.gif";
    $image5 = "http://www.shukitchan.com/photostick/images/bowl1.gif";
  }
}
else
{
  $target_stick = "fun";
}

?>

<div align="center">
<iframe src="http://www.shukitchan.com/photostick/ads.php" scrolling="no" frameborder="0" width="600" height="75"/>
</div>

<?php
if($target_pid && isset($target_pid) && $target_pid !="")
{

?>
<div id="photoselect" style="width:99%;height:500px;overflow:auto;padding:3px;border:1px grey solid;">

<div style="padding-top: 5px; padding-left: 10px; background-color: #666666; color: white; height: 20px;" align="center">
<a href="http://apps.facebook.com/photostick/" style="color: white;">Photo Sticker</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="http://apps.facebook.com/photostick/selector.php" style="color: white;">Tell Your Friend</a>
</div>

<div id="selector" style="position:relative;width:90%;height:50px;top:10px;left:20px;">

<form id="stickform" action="http://apps.facebook.com/photostick/index.php">
<input type="hidden" name="pid" id="pid" value="<?=$target_pid?>"/>
<input type="hidden" name="stick" id="stick" value=""/>
<input type="hidden" name="zwidth" id="zwidth" value="<?=$target_zwidth?>"/>
<input type="hidden" name="zheight" id="zheight" value="<?=$target_zheight?>"/>
Choose a sticker set: <a onClick="document.getElementById('stick').setValue('fun');document.getElementById('stickform').submit();">Fun</a>&nbsp;
<a onClick="document.getElementById('stick').setValue('love');document.getElementById('stickform').submit();">Love</a>&nbsp;
<a onClick="document.getElementById('stick').setValue('mean');document.getElementById('stickform').submit();">Mean</a>&nbsp;
<a onClick="document.getElementById('stick').setValue('sports');document.getElementById('stickform').submit();">Sports</a>&nbsp;
</form>
<form id="builder" action="http://apps.facebook.com/photostick/builder1.php">
<input type="hidden" name="pid" id="pid" value="<?=$target_pid?>"/>
<input type="hidden" name="stick" id="stick" value="<?=$target_stick?>"/>
<input type="hidden" name="zwidth" id="zwidth" value="<?=$target_zwidth?>"/>
<input type="hidden" name="zheight" id="zheight" value="<?=$target_zheight?>"/>
<input type="hidden" name="d1_x" id="d1_x" value=""/>
<input type="hidden" name="d1_y" id="d1_y" value=""/>
<input type="hidden" name="d2_x" id="d2_x" value=""/>
<input type="hidden" name="d2_y" id="d2_y" value=""/>
<input type="hidden" name="d3_x" id="d3_x" value=""/>
<input type="hidden" name="d3_y" id="d3_y" value=""/>
<input type="hidden" name="d4_x" id="d4_x" value=""/>
<input type="hidden" name="d4_y" id="d4_y" value=""/>
<input type="hidden" name="d5_x" id="d5_x" value=""/>
<input type="hidden" name="d5_y" id="d5_y" value=""/>
Drag and drop stickers to the photo. When done, <a onClick="document.getElementById('builder').submit();">Click here to upload the vandalized photo to your account.</a>
</form>
</div>

<?php
if($target_zwidth > $target_zheight)
{
  $size = "width:302px;height:auto;";
}
else
{
  $size = "width:auto;height:302px;";
}
?>
<div align="center">
<div id="container" style="position:relative;width:312px;height:375px;overflow:hidden;border:1px solid rgb(200,200,200);text-align:left;">
<div style="position:relative;width:310px;height:310px;border:1px solid rgb(200,200,200);">

	<div id="dropzones" align="center" style="position:relative;top:5px;left:0px;text-align:center;">
          <?php
            $rs = $facebook->api(array(
                    'method' => 'fql.query',
                    'query' => "SELECT src_big FROM photo WHERE pid = $target_pid",
                     ));
            $src = $rs[0]["src_big"];
            print "<img src=\"$src\" pid=\"$target_pid\" style=\"$size\"/>";
            //print "<fb:photo style=\"$size\" pid=\"$target_pid\"/>";
          ?>
	</div>
</div>
	<div id="d1" style="position:relative;left:5px;top:5px;height:60px;width:60px;background-color:transparent;">
          <img style="position:relative;height:60px;width:60px;" src="<?=$image1?>"/>
        </div>
	<div id="d2" style="position:relative;left:65px;top:-55px;height:60px;width:60px;background-color:transparent;">
          <img style="position:relative;height:60px;width:60px;" src="<?=$image2?>"/>
        </div>
	<div id="d3" style="position:relative;left:125px;top:-115px;height:60px;width:60px;background-color:transparent;">
          <img style="position:relative;height:60px;width:60px;" src="<?=$image3?>"/>
        </div>
	<div id="d4" style="position:relative;left:185px;top:-175px;height:60px;width:60px;background-color:transparent;">
          <img style="position:relative;height:60px;width:60px;" src="<?=$image4?>"/>
        </div>
	<div id="d5" style="position:relative;left:245px;top:-235px;height:60px;width:60px;background-color:transparent;">
          <img style="position:relative;height:60px;width:60px;" src="<?=$image5?>"/>
        </div>
</div>
</div>
<script>
//if (browser == "EVIL")
//{
//	document.getElementById('dropzones').setStyle('top', '-400px');
//}
	
// Create a draggable "window" out of the provided element
var d1 = createPane(document.getElementById('d1'));
Drag.init(d1);
d1.onDragEnd = function(x,y)
{
  document.getElementById('d1_x').setValue(x);
  document.getElementById('d1_y').setValue(y);
}


var d2 = createPane(document.getElementById('d2'));
Drag.init(d2);
d2.onDragEnd = function(x,y)
{
  document.getElementById('d2_x').setValue(x);
  document.getElementById('d2_y').setValue(y);
}

var d3 = createPane(document.getElementById('d3'));
Drag.init(d3);
d3.onDragEnd = function(x,y)
{
  document.getElementById('d3_x').setValue(x);
  document.getElementById('d3_y').setValue(y);
}

var d4 = createPane(document.getElementById('d4'));
Drag.init(d4);
d4.onDragEnd = function(x,y)
{
  document.getElementById('d4_x').setValue(x);
  document.getElementById('d4_y').setValue(y);
}

var d5 = createPane(document.getElementById('d5'));
Drag.init(d5);
d5.onDragEnd = function(x,y)
{
  document.getElementById('d5_x').setValue(x);
  document.getElementById('d5_y').setValue(y);
}

</script>
</div>

<?php
}else{
?>

<div id="photoselect" style="width:99%;height:700px;overflow:auto;padding:3px;border:1px grey solid;">

<div style="padding-top: 5px; padding-left: 10px; background-color: #666666; color: white; height: 20px;" align="center">
<a href="http://apps.facebook.com/photostick/" style="color: white;">Photo Sticker</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="http://apps.facebook.com/photostick/selector.php" style="color: white;">Tell Your Friend</a>
</div>

<form id="photoform">

<div id="selector" style="position:relative;width:70%;height:30px;top:10px;left:20px;">
Choose a photo album: <select name="aid" onChange="document.getElementById('photoform').submit();">
<option value=""></option>
<?php

$rs = $facebook->api(array(
                    'method' => 'fql.query',
                    'query' => "SELECT aid, name FROM album WHERE owner=me()",
                     ));

if ($rs)
{
  //$albums = $rs['album'];
  $albums = $rs;
  if($albums)
  {
        if(isset($albums["aid"]))
        {
          print "<option value=\"{$albums["aid"]}\"";
          if($albums["aid"] === $target_aid)
          {
            print " SELECTED=\"\" ";
          }
          print ">{$albums["name"]}</option>";  
        }
        else
        {
	  for ( $i = 0; $i < count($albums); $i++ )
	  {	
		print "<option value=\"{$albums[$i]["aid"]}\"";
                if($albums[$i]["aid"] === $target_aid)
                {
                  print " SELECTED=\"\" ";
                }
                print ">{$albums[$i]["name"]}</option>";
	  }
        }
  }
}

?>
</select>
<?php

if($target_aid && isset($target_aid) && $target_aid!='')
{

  $rs = $facebook->api(array(
                    'method' => 'fql.query',
                    'query' => "SELECT pid, src, src_small, src_big FROM photo WHERE aid=$target_aid",
                       ));

  //$photos = $rs['photo'];
  $photos = $rs;
  if($photos)
  {
    if(!isset($photos["pid"]))
    {
      $pages = ceil(count($photos) / 16);
      $pagination = <<<FBML
&nbsp;&nbsp;&nbsp;
Page: <select name="page" onChange="document.getElementById('photoform').submit();">
FBML;
    
      for($i = 0; $i < $pages; $i++)
      {
          $read_page = $i + 1;
          $pagination .= "<option value=\"{$i}\"";
          if($target_page === $i)
          {
            $pagination .= " SELECTED=\"\" ";
          }
          $pagination .= ">{$read_page}</option>";  
      }
      $pagination .= "</select>";
      print $pagination;
    }
  }  
  echo '<br/><br/>Please click on a photo to put stickers on<br/>';

if($rs)
{
  //$photos = $rs['photo'];
  $photos = $rs;
  if($photos)
  {
    print "<div style=\"position:relative;top:10px;\">";
    print "<input type=\"hidden\" name=\"pid\" id=\"pid\" value=\"\"/>";
    print "<input type=\"hidden\" name=\"zwidth\" id=\"zwidth\" value=\"\"/>";
    print "<input type=\"hidden\" name=\"zheight\" id=\"zheight\" value=\"\"/>";
    if(isset($photos["pid"]))
    {
          print "<div style=\"position:absolute;top:0px;left:0px;text-align:center;width:141px;height:141px;\">";
          print "<div style=\"width:135px;height:135px;border:3px solid rgb(200,200,200);\">";
          print "<a onClick=\"document.getElementById('pid').setValue('{$photos["pid"]}');document.getElementById('zwidth').setValue(document.getElementById('{$photos["pid"]}').getClientWidth());document.getElementById('zheight').setValue(document.getElementById('{$photos["pid"]}').getClientHeight());document.getElementById('photoform').submit();\"><img id=\"{$photos["pid"]}\" src=\"{$photos["src"]}\"/></a>";
          print "</div></div>";
    }
    else
    {
        $count = 0;
	for ( $i = ($target_page*16); $i < count($photos); $i++ )
	{
          $top = floor($i/4) * 150;
          $top = $top - ($target_page*600);
          $left = ($i % 4) * 150;
          print "<div style=\"position:absolute;top:{$top}px;left:{$left}px;text-align:center;width:141px;height:141px;\">";
          print "<div style=\"width:135px;height:135px;border:3px solid rgb(200,200,200);\">";
          print "<a onClick=\"document.getElementById('pid').setValue('{$photos[$i]["pid"]}');document.getElementById('zwidth').setValue(document.getElementById('{$photos[$i]["pid"]}').getClientWidth());document.getElementById('zheight').setValue(document.getElementById('{$photos[$i]["pid"]}').getClientHeight());document.getElementById('photoform').submit();\"><img id=\"{$photos[$i]["pid"]}\" src=\"{$photos[$i]["src"]}\"/></a>";
          print "</div></div>";
          $count++;
          if($count == 16)
          {  
            break;
          }
	}
    }
    print "</div>";
  }
}
  print"</div></form></div>";
}
else
{
?>
<div align="center">
<iframe src="http://www.shukitchan.com/photostick/lads.php" scrolling="no" frameborder="0" width="720" height="400"/>
</div>
</div>
</form>
</div>
<?php
  }
}
?>
