<?php
/* include the PHP Facebook Client Library to help
  with the API calls and make life easy */
require_once('appinclude.php');

$target_pid = $_GET['pid'];
$target_zwidth = $_GET['zwidth'];
$target_zheight = $_GET['zheight'];
$d1_x = floor(($_GET['d1_x']? $_GET['d1_x'] : "5"));
$d1_y = floor(($_GET['d1_y']? $_GET['d1_y'] : "1000"));
$d2_x = floor(($_GET['d2_x']? $_GET['d2_x'] : "65"));
$d2_y = floor(($_GET['d2_y']? $_GET['d2_y'] : "1000"));
$d3_x = floor(($_GET['d3_x']? $_GET['d3_x'] : "125"));
$d3_y = floor(($_GET['d3_y']? $_GET['d3_y'] : "1000"));
$d4_x = floor(($_GET['d4_x']? $_GET['d4_x'] : "185"));
$d4_y = floor(($_GET['d4_y']? $_GET['d4_y'] : "1000"));
$d5_x = floor(($_GET['d5_x']? $_GET['d5_x'] : "245"));
$d5_y = floor(($_GET['d5_y']? $_GET['d5_y'] : "1000"));

$narrow_d1_x = floor(($_GET['d1_x']? $_GET['d1_x'] : "5")/2);
$narrow_d1_y = floor(($_GET['d1_y']? $_GET['d1_y'] : "1000")/2);
$narrow_d2_x = floor(($_GET['d2_x']? $_GET['d2_x'] : "65")/2);
$narrow_d2_y = floor(($_GET['d2_y']? $_GET['d2_y'] : "1000")/2);
$narrow_d3_x = floor(($_GET['d3_x']? $_GET['d3_x'] : "125")/2);
$narrow_d3_y = floor(($_GET['d3_y']? $_GET['d3_y'] : "1000")/2);
$narrow_d4_x = floor(($_GET['d4_x']? $_GET['d4_x'] : "185")/2);
$narrow_d4_y = floor(($_GET['d4_y']? $_GET['d4_y'] : "1000")/2);
$narrow_d5_x = floor(($_GET['d5_x']? $_GET['d5_x'] : "245")/2);
$narrow_d5_y = floor(($_GET['d5_y']? $_GET['d5_y'] : "1000")/2);

$target_stick = $_GET['stick'];

$image1 = "http://www.shukitchan.com/photostick/images/me1.gif";
$image2 = "http://www.shukitchan.com/photostick/images/her1.gif";
$image3 = "http://www.shukitchan.com/photostick/images/beer1.gif";
$image4 = "http://www.shukitchan.com/photostick/images/cake1.gif";
$image5 = "http://www.shukitchan.com/photostick/images/money1.gif";

if($target_stick && isset($target_stick))
{
  if($target_stick == 'wwu')
  {
    $image1 = "http://www.shukitchan.com/photostick/images/bears1.gif";
    $image2 = "http://www.shukitchan.com/photostick/images/key1.gif";
    $image3 = "http://www.shukitchan.com/photostick/images/stpauls1.gif";
    $image4 = "http://www.shukitchan.com/photostick/images/tree1.gif";
    $image5 = "http://www.shukitchan.com/photostick/images/koala1.gif";
  }
  else if($target_stick == 'love')
  {
    $image1 = "http://www.shukitchan.com/photostick/images/heart1.gif";
    $image2 = "http://www.shukitchan.com/photostick/images/rose1.gif";
    $image3 = "http://www.shukitchan.com/photostick/images/diamond1.gif";
    $image4 = "http://www.shukitchan.com/photostick/images/kiss1.gif";
    $image5 = "http://www.shukitchan.com/photostick/images/glass1.gif";
  }
  else if($target_stick == 'fun')
  {
    $image1 = "http://www.shukitchan.com/photostick/images/me1.gif";
    $image2 = "http://www.shukitchan.com/photostick/images/her1.gif";
    $image3 = "http://www.shukitchan.com/photostick/images/beer1.gif";
    $image4 = "http://www.shukitchan.com/photostick/images/cake1.gif";
    $image5 = "http://www.shukitchan.com/photostick/images/money1.gif";
  }
  else if($target_stick == 'mean')
  {
    $image1 = "http://www.shukitchan.com/photostick/images/cross1.gif";
    $image2 = "http://www.shukitchan.com/photostick/images/toilet1.gif";
    $image3 = "http://www.shukitchan.com/photostick/images/skull1.gif";
    $image4 = "http://www.shukitchan.com/photostick/images/stop1.gif";
    $image5 = "http://www.shukitchan.com/photostick/images/biohazard1.gif";
  }
  else if($target_stick == 'sports')
  {
    $image1 = "http://www.shukitchan.com/photostick/images/bball1.gif";
    $image2 = "http://www.shukitchan.com/photostick/images/glove1.gif";
    $image3 = "http://www.shukitchan.com/photostick/images/football1.gif";
    $image4 = "http://www.shukitchan.com/photostick/images/soccer1.gif";
    $image5 = "http://www.shukitchan.com/photostick/images/bowl1.gif";
  }
}

?>

<div align="center">
<iframe src="http://www.shukitchan.com/photostick/ads.php" scrolling="no" frameborder="0" width="600" height="75"/>
</div>

<?php

if($target_zwidth > $target_zheight)
{
  $size = "width:302px;height:auto;";
  $narrow_size = "width:151px;height:auto;";
}
else
{
  $size = "width:auto;height:302px;";
  $narrow_size = "width:auto;height:151px;";
}

$txt=<<<FBML

<div align="center">
<div id="container" style="width:312px;height:312px;overflow:hidden;border:1px grey solid;z-index:-2;text-align:left;">
<div style="width:310px;height:310px;border:1px solid rgb(200,200,200);z-index:-2;">

	<div id="dropzones" align="center" style="position:relative;top:5px;text-align:center;">
          <fb:photo style="{$size}" pid="$target_pid"/>
	</div>
</div>

	<div id="d1" style="position:relative;left:{$d1_x}px;top:{$d1_y}px;height:60px;width:60px;background-color:transparent;">
          <img style="width:60px;height:60px;" src="$image1"/>
        </div>
	<div id="d2" style="position:relative;left:{$d2_x}px;top:{$d2_y}px;height:60px;width:60px;background-color:transparent;">
          <img style="width:60px;height:60px;" src="$image2"/>
        </div>
	<div id="d3" style="position:relative;left:{$d3_x}px;top:{$d3_y}px;height:60px;width:60px;background-color:transparent;">
          <img style="width:60px;height:60px;" src="$image3"/>
        </div>
	<div id="d4" style="position:relative;left:{$d4_x}px;top:{$d4_y}px;height:60px;width:60px;background-color:transparent;">
          <img style="width:60px;height:60px;" src="$image4"/>
        </div>
	<div id="d5" style="position:relative;left:{$d5_x}px;top:{$d5_y}px;height:60px;width:60px;background-color:transparent;">
          <img style="width:60px;height:60px;" src="$image5"/>
        </div>

</div>
</div>
FBML;

?>

<fb:tabs>  
  <fb:tab-item href='http://apps.facebook.com/photostick/' title='Photo Sticker' selected='true'/>  
  <fb:tab-item href='http://apps.facebook.com/photostick/selector.php' title='Tell Your Friend' selected='false'/>  
</fb:tabs>

<?=$txt?>
<br/>
