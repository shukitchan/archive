<?php
/* include the PHP Facebook Client Library to help
  with the API calls and make life easy */
require_once('appinclude.php');

$target_pid = $_GET['pid'];
$target_zwidth = $_GET['zwidth'];
$target_zheight = $_GET['zheight'];

$dd1_x = $_GET['d1_x'];
$dd1_y = $_GET['d1_y'];
$dd2_x = $_GET['d2_x'];
$dd2_y = $_GET['d2_y'];
$dd3_x = $_GET['d3_x'];
$dd3_y = $_GET['d3_y'];
$dd4_x = $_GET['d4_x'];
$dd4_y = $_GET['d4_y'];
$dd5_x = $_GET['d5_x'];
$dd5_y = $_GET['d5_y'];

$d1_x = floor(($_GET['d1_x']? $_GET['d1_x'] : "5"));
$d1_y = floor(($_GET['d1_y']? $_GET['d1_y'] : "1000"));
$d2_x = floor(($_GET['d2_x']? $_GET['d2_x'] : "65"));
$d2_y = floor(($_GET['d2_y']? $_GET['d2_y'] : "1000"));
$d3_x = floor(($_GET['d3_x']? $_GET['d3_x'] : "125"));
$d3_y = floor(($_GET['d3_y']? $_GET['d3_y'] : "1000"));
$d4_x = floor(($_GET['d4_x']? $_GET['d4_x'] : "185"));
$d4_y = floor(($_GET['d4_y']? $_GET['d4_y'] : "1000"));
$d5_x = floor(($_GET['d5_x']? $_GET['d5_x'] : "245"));
$d5_y = floor(($_GET['d5_y']? $_GET['d5_y'] : "1000"));

$target_stick = $_GET['stick'];

$image1 = "http://www.shukitchan.com/photostick/images/me1.gif";
$image2 = "http://www.shukitchan.com/photostick/images/her1.gif";
$image3 = "http://www.shukitchan.com/photostick/images/beer1.gif";
$image4 = "http://www.shukitchan.com/photostick/images/cake1.gif";
$image5 = "http://www.shukitchan.com/photostick/images/money1.gif";

if($target_stick && isset($target_stick))
{
  if($target_stick == 'wwu')
  {
    $image1 = "http://www.shukitchan.com/photostick/images/bears1.gif";
    $image2 = "http://www.shukitchan.com/photostick/images/key1.gif";
    $image3 = "http://www.shukitchan.com/photostick/images/stpauls1.gif";
    $image4 = "http://www.shukitchan.com/photostick/images/tree1.gif";
    $image5 = "http://www.shukitchan.com/photostick/images/koala1.gif";
  }
  else if($target_stick == 'love')
  {
    $image1 = "http://www.shukitchan.com/photostick/images/heart1.gif";
    $image2 = "http://www.shukitchan.com/photostick/images/rose1.gif";
    $image3 = "http://www.shukitchan.com/photostick/images/diamond1.gif";
    $image4 = "http://www.shukitchan.com/photostick/images/kiss1.gif";
    $image5 = "http://www.shukitchan.com/photostick/images/glass1.gif";
  }
  else if($target_stick == 'fun')
  {
    $image1 = "http://www.shukitchan.com/photostick/images/me1.gif";
    $image2 = "http://www.shukitchan.com/photostick/images/her1.gif";
    $image3 = "http://www.shukitchan.com/photostick/images/beer1.gif";
    $image4 = "http://www.shukitchan.com/photostick/images/cake1.gif";
    $image5 = "http://www.shukitchan.com/photostick/images/money1.gif";
  }
  else if($target_stick == 'mean')
  {
    $image1 = "http://www.shukitchan.com/photostick/images/cross1.gif";
    $image2 = "http://www.shukitchan.com/photostick/images/toilet1.gif";
    $image3 = "http://www.shukitchan.com/photostick/images/skull1.gif";
    $image4 = "http://www.shukitchan.com/photostick/images/stop1.gif";
    $image5 = "http://www.shukitchan.com/photostick/images/biohazard1.gif";
  }
  else if($target_stick == 'sports')
  {
    $image1 = "http://www.shukitchan.com/photostick/images/bball1.gif";
    $image2 = "http://www.shukitchan.com/photostick/images/glove1.gif";
    $image3 = "http://www.shukitchan.com/photostick/images/football1.gif";
    $image4 = "http://www.shukitchan.com/photostick/images/soccer1.gif";
    $image5 = "http://www.shukitchan.com/photostick/images/bowl1.gif";
  }
}

?>

<div align="center">
<iframe src="http://www.shukitchan.com/photostick/ads.php" scrolling="no" frameborder="0" width="600" height="75"/>
</div>

<?php

if($target_zwidth > $target_zheight)
{
  $size = "width:302px;height:auto;";
}
else
{
  $size = "width:auto;height:302px;";
}

$rs = $facebook->api(array(
          'method' => 'fql.query',
          'query' => "SELECT src_big FROM photo WHERE pid = $target_pid",
                     ));
$src = $rs[0]["src_big"];

$txt=<<<FBML

<div align="center">
<div id="container" style="width:312px;height:312px;overflow:hidden;border:1px grey solid;z-index:-2;text-align:left;">
<div style="width:310px;height:310px;border:1px solid rgb(200,200,200);z-index:-2;">

	<div id="dropzones" align="center" style="position:relative;top:5px;text-align:center;">
          <img src="$src" pid="$target_pid" style="$size"/>
	</div>
</div>

	<div id="d1" style="position:relative;left:{$d1_x}px;top:{$d1_y}px;height:60px;width:60px;background-color:transparent;">
          <img style="width:60px;height:60px;" src="$image1"/>
        </div>
	<div id="d2" style="position:relative;left:{$d2_x}px;top:{$d2_y}px;height:60px;width:60px;background-color:transparent;">
          <img style="width:60px;height:60px;" src="$image2"/>
        </div>
	<div id="d3" style="position:relative;left:{$d3_x}px;top:{$d3_y}px;height:60px;width:60px;background-color:transparent;">
          <img style="width:60px;height:60px;" src="$image3"/>
        </div>
	<div id="d4" style="position:relative;left:{$d4_x}px;top:{$d4_y}px;height:60px;width:60px;background-color:transparent;">
          <img style="width:60px;height:60px;" src="$image4"/>
        </div>
	<div id="d5" style="position:relative;left:{$d5_x}px;top:{$d5_y}px;height:60px;width:60px;background-color:transparent;">
          <img style="width:60px;height:60px;" src="$image5"/>
        </div>

</div>
</div>
FBML;


//$ch = curl_init ("http://ec2-50-16-9-162.compute-1.amazonaws.com/test-image2.php?stick=$target_stick&d1_x=236&d1_y=-170&d2_x=233&d2_y=-366&d3_x=45&d3_y=-291&d4_x=125&d4_y=-362&d5_x=126&d5_y=-554&url=http://a7.sphotos.ak.fbcdn.net/hphotos-ak-ash2/168119_10150146071831729_20531316728_7844072_5116892_n.jpg");
//curl_setopt($ch, CURLOPT_HEADER, 0);
//curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
//curl_setopt($ch, CURLOPT_BINARYTRANSFER,1);
//curl_setopt($ch, CURLOPT_VERBOSE, true);
//$image=curl_exec($ch);
//curl_close ($ch);

//error_log($image);

//$facebook->setFileUploadSupport(true);
//$args = array('message' => 'Photo Caption');
//$args['image'] = '@'.realpath('images/bball.gif');
//$data = $facebook->api('/me/photos', 'post', $args);


$tok = $facebook->getAccessToken();
$url = "http://ec2-50-16-9-162.compute-1.amazonaws.com/submit.php?stick=$target_stick&d1_x=$dd1_x&d1_y=$dd1_y&d2_x=$dd2_x&d2_y=$dd2_y&d3_x=$dd3_x&d3_y=$dd3_y&d4_x=$dd4_x&d4_y=$dd4_y&d5_x=$dd5_x&d5_y=$dd5_y&url=$src&access_token=$tok";
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_HEADER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$data = curl_exec($ch);

$msg = "Your Vandalized Photo is uploaded!!!";
if($data == false){
  $msg = "Sorry! Some problems. Please try again.";
}
?>

<div id="photoselect" style="width:99%;height:500px;overflow:auto;padding:3px;border:1px grey solid;">

<div style="padding-top: 5px; padding-left: 10px; background-color: #666666; color: white; height: 20px;" align="center">
<a href="http://apps.facebook.com/photostick/" style="color: white;">Photo Sticker</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="http://apps.facebook.com/photostick/selector.php" style="color: white;">Tell Your Friend</a>
</div>

<br/><?=$msg?><br/>
<?=$txt?>
<br/>
</div>
