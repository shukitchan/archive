<?php
require_once 'facebook.php';

$appid = '19670814168';
$appsecret = '3c86d15b49daac4a4dcd56cc5997c100';
$canvaspage = 'http://apps.facebook.com/photostick';

// init 
$facebook = new Facebook(array(
  'appId' => $appid,
  'secret' => $appsecret,
  'fileUpload' => true
));

//error detection
if(isset($_REQUEST["error"]))
{
  $error = $_REQUEST["error"];
  echo "<h2>". $error. "</h2>";
  echo "Please click <a href=\"$canvaspage\">here</a> and try again. ";
  exit(0);
}

// authentication
$auth_url = "http://www.facebook.com/dialog/oauth?client_id=" 
            . $appid . "&redirect_uri=" . urlencode($canvaspage) 
            . "&scope=user_photos,publish_stream";

//error_log($auth_url);

if(!isset($_REQUEST["signed_request"]))
{
  echo("<fb:redirect url='" . $auth_url . "'/>");
  exit(0);
}

$signed_request = $facebook->getSignedRequest();
if (empty($signed_request["user_id"])) 
{
  echo("<fb:redirect url='" . $auth_url . "'/>");
  exit(0);
}

error_log($signed_request["user_id"]);

$user = $facebook->getUser();

if (!$user) 
{
  echo("<fb:redirect url='" . $auth_url . "'/>");
  exit(0);
}

?>