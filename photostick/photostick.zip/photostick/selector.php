<?php
/* include the PHP Facebook Client Library to help
  with the API calls and make life easy */
require_once('appinclude.php');
?>

<iframe src="http://www.shukitchan.com/photostick/ads.php" scrolling="no" frameborder="0" width="650" height="75"/>

<fb:tabs>  
  <fb:tab-item href='http://apps.facebook.com/photostick/' title='Photo Sticker' selected='false'/>  

  <fb:tab-item href='http://apps.facebook.com/photostick/selector.php' title='Tell Your Friend' selected='true'/>  

</fb:tabs>

<div id="selector" style="position:relative;width:70%;height:30px;top:10px;left:20px;">
<p>Please share this application with friends.</p>
</div>

<br/>

<?php
$rs = $facebook->api(array(
        'method' => 'fql.query',
        'query' => "SELECT uid FROM user WHERE uid IN (SELECT uid2 FROM friend WHERE uid1 = me())",
                     ));

$arFriends = "";

//  Build an delimited list of users...
if ($rs)
{
  if(isset($rs["uid"]))
  {
    $arFriends = $rs["uid"];
  }
  else
  {
	for ( $i = 0; $i < count($rs); $i++ )
	{
		if ( $arFriends != "" )
			$arFriends .= ",";
	
		$arFriends .= $rs[$i]["uid"];
	}
  }
}

$arFriends = "";

//  Construct a next url for referrals
$sNextUrl = urlencode("");

//  Build your invite text
$invfbml = <<<FBML
<fb:name uid="$user" firstnameonly="true" shownetwork="false"/> has put up a nice photo enhanced with photostickers and would like you to add this application to check out the fun picture. 
<fb:req-choice url="http://www.facebook.com/add.php?api_key=$appapikey&next=$sNextUrl" label="Add the Application" />
FBML;

?>

<fb:request-form type="Photo Sticker" action="/profile.php" content="<?=htmlentities($invfbml)?>" invite="true">
	<fb:multi-friend-selector max="20" rows="3" actiontext="Invite your friends to add this fun application!" showborder="true" exclude_ids="<?=$arFriends?>">
</fb:request-form>
