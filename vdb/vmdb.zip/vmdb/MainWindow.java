
//Title:      VMDB
//Version:
//Copyright:  Copyright (c) 1999
//Author:     Shu Kit Chan
//Company:
//Description:Java Application to export database program for Sega VMU
package vmdb;

import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.*;
import java.io.*;

public class MainWindow extends JFrame {
  // data
  DBModel db = new DBModel();
  File file = null;

  // control
  JMenuBar menuBar1 = new JMenuBar();
  JMenu menuFile = new JMenu();
  JMenuItem menuFileExit = new JMenuItem();
  JMenu menuHelp = new JMenu();
  JMenuItem menuHelpAbout = new JMenuItem();
  JLabel statusBar = new JLabel();
  BorderLayout borderLayout1 = new BorderLayout();
  JMenuItem menuFileOpen = new JMenuItem();
  JMenuItem menuFileNew = new JMenuItem();
  JMenuItem menuFileSave = new JMenuItem();
  JMenu menuOutput = new JMenu();
  JMenuItem menuOutputFile = new JMenuItem();
  JMenuItem menuFileSaveAs = new JMenuItem();
  JScrollPane jScrollPane1 = new JScrollPane();
  JTable jTable1 = new JTable(db);

  //Construct the frame
  public MainWindow() {
    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    try  {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  //Component initialization
  private void jbInit() throws Exception  {
    this.getContentPane().setLayout(borderLayout1);
    this.setSize(new Dimension(400, 300));
    this.setTitle("VMDB");
    statusBar.setText(" ");

    menuFile.setText("File");
    menuFileExit.setText("Exit");
    menuFileExit.addActionListener(new ActionListener()  {
      public void actionPerformed(ActionEvent e) {
        fileExit_actionPerformed(e);
      }
    });
    menuHelp.setText("Help");
    menuHelpAbout.setText("About");
    menuHelpAbout.addActionListener(new ActionListener()  {
      public void actionPerformed(ActionEvent e) {
        helpAbout_actionPerformed(e);
      }
    });
    menuFileOpen.setText("Open");
    menuFileOpen.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        fileOpen_actionPerformed(e);
      }
    });
    menuFileNew.setText("New");
    menuFileNew.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        fileNew_actionPerformed(e);
      }
    });
    menuFileSave.setText("Save");
    menuFileSave.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        fileSave_actionPerformed(e);
      }
    });
    menuOutput.setText("Output");
    menuOutputFile.setText("File");
    menuOutputFile.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        outputFile_actionPerformed(e);
      }
    });
    menuOutputFile.setActionCommand("OutputFile");
    menuFileSaveAs.setText("Save As");
    menuFileSaveAs.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        fileSaveAs_actionPerformed(e);
      }
    });
    menuFile.add(menuFileNew);
    menuFile.add(menuFileOpen);
    menuFile.add(menuFileSave);
    menuFile.add(menuFileSaveAs);
    menuFile.addSeparator();
    menuFile.add(menuFileExit);
    menuHelp.add(menuHelpAbout);
    menuBar1.add(menuFile);
    menuBar1.add(menuOutput);
    menuBar1.add(menuHelp);
    this.setJMenuBar(menuBar1);
    this.getContentPane().add(statusBar, BorderLayout.SOUTH);
    this.getContentPane().add(jScrollPane1, BorderLayout.CENTER);
    jScrollPane1.getViewport().add(jTable1, null);
    menuOutput.add(menuOutputFile);

    SixCharTextField t = new SixCharTextField();
    DefaultCellEditor editor = new DefaultCellEditor(t);
    jTable1.setDefaultEditor(String.class, editor);
  }

  public void outputFile_actionPerformed(ActionEvent e) {
    jTable1.editingStopped(null);

    JFileChooser chooser = new JFileChooser();
    ExtensionFileFilter filter = new ExtensionFileFilter();
    filter.addExtension("vms");
    filter.setDescription("VMS files");
    chooser.setFileFilter(filter);
    int returnVal = chooser.showSaveDialog(this);
    if(returnVal == JFileChooser.APPROVE_OPTION) {
      File vms = chooser.getSelectedFile();
      String fileName = vms.getName();
      if(fileName.length() > 12 ||
         !fileName.toUpperCase().endsWith(".VMS") ||
         !fileName.equals(fileName.toUpperCase())) {
        statusBar.setText("File name must end with .VMS and under 12 chars");
        return;
      }
      try {
        FileOutputStream cout = new FileOutputStream(vms);
        InputStream cin = this.getClass().getResource("VDB.VMS").openStream();

        StringBuffer data = new StringBuffer();
        for(int i = 0; i < 64; i++) {
          String [] d = db.getDataRow(i);
          if((d[0]!=null&&!d[0].equals("")) ||
             (d[1]!=null&&!d[1].equals("")) ||
             (d[2]!=null&&!d[2].equals("")) ||
             (d[3]!=null&&!d[3].equals(""))) {
             for(int j = 0; j<4; j++) {
               if(d[j] != null) {
                 for(int k= 0; k < 6;k++) {
                   if(d[j].length() <= k) {
                     data.append(" ");
                   } else {
                     data.append(d[j].substring(k,k+1));
                   }
                 }
               } else {
                 data.append("      ");
               }
             }
             data.append("        ");
          }
        }

        String result = data.toString();
        int num = result.length()/32;

        int ava = cin.available();
        byte [] b = new byte[1];
        for(int i = 0; i < ava; i++) {
          cin.read(b);
          if(i >= 3976 && i < 3976+result.length()) {
            b[0] = (byte) result.charAt(i-3976);
          } else if(i == 1219){
            b[0] = (byte) num;
          }
          cout.write(b);
        }

        cin.close();
        cout.close();

        String tempName = vms.getAbsolutePath();
        tempName = tempName.substring(0,tempName.length() - 3) +"VMI";
        File vmi = new File(tempName);

        String fName = vmi.getName();
        String resourceName = fileName.substring(0,fName.toUpperCase().indexOf(".VMI"));
        resourceName = resourceName.toUpperCase();
        fName = fName.substring(0,fName.length()-4).toUpperCase();
        FileOutputStream vmicout = new FileOutputStream(vmi);

        b = new byte[108];
        if(fileName.length() > 0){
          b[0] = (byte) (((int) resourceName.charAt(0)) & 0x53);
        } else {
          b[0] = (0x00);
        }
        if(fileName.length() > 1){
          b[1] = (byte) (((int) resourceName.charAt(1)) & 0x45);
        } else {
          b[1] = (0x00);
        }
        if(fileName.length() > 2){
          b[2] = (byte) (((int) resourceName.charAt(2)) & 0x47);
        } else {
          b[2] = (0x00);
        }
        if(fileName.length() > 3){
          b[3] = (byte) (((int) resourceName.charAt(3)) & 0x41);
        } else {
          b[3] = (0x00);
        }
        b[4] = 'V';
        b[5] = 'M';
        b[6] = 'S';
        b[7] = ' ';
        b[8] = 'D';
        b[9] = 'a';
        b[10] = 't';
        b[11] = 'a';
        b[12] = 'b';
        b[13] = 'a';
        b[14] = 's';
        b[15] = 'e';
        b[16] = ' ';
        b[17] = ' ';
        b[18] = ' ';
        b[19] = ' ';
        b[20] = ' ';
        b[21] = ' ';
        b[22] = ' ';
        b[23] = ' ';
        b[24] = ' ';
        b[25] = ' ';
        b[26] = ' ';
        b[27] = ' ';
        b[28] = ' ';
        b[29] = ' ';
        b[30] = ' ';
        b[31] = ' ';
        b[32] = ' ';
        b[33] = ' ';
        b[34] = ' ';
        b[35] = ' ';
        b[36] = 'b';
        b[37] = 'y';
        b[38] = ' ';
        b[39] = 'K';
        b[40] = 'i';
        b[41] = 't';
        b[42] = ' ';
        b[43] = 'C';
        b[44] = 'h';
        b[45] = 'a';
        b[46] = 'n';
        b[47] = '(';
        b[48] = 'l';
        b[49] = 'g';
        b[50] = 'l';
        b[51] = 'v';
        b[52] = ')';
        b[53] = ' ';
        b[54] = ' ';
        b[55] = ' ';
        b[56] = ' ';
        b[57] = ' ';
        b[58] = ' ';
        b[59] = ' ';
        b[60] = ' ';
        b[61] = ' ';
        b[62] = ' ';
        b[63] = ' ';
        b[64] = ' ';
        b[65] = ' ';
        b[66] = ' ';
        b[67] = ' ';
        b[68] = (byte) 0xD1;
        b[69] = 0x07;
        b[70] = (byte) 0x0A;
        b[71] = 0x14;
        b[72] = 0x00;
        b[73] = 0x00;
        b[74] = 0x00;
        b[75] = 0x05;
        b[76] = 0x00;
        b[77] = 0x00;
        b[78] = 0x01;
        b[79] = 0x00;
        if(resourceName.length() > 0) {
          b[80] = (byte) resourceName.charAt(0);
        } else {
          b[80] = 0x00;
        }
        if(resourceName.length() > 1) {
          b[81] = (byte) resourceName.charAt(1);
        } else {
          b[81] = 0x00;
        }
        if(resourceName.length() > 2) {
          b[82] = (byte) resourceName.charAt(2);
        } else {
          b[82] = 0x00;
        }
        if(resourceName.length() > 3) {
          b[83] = (byte) resourceName.charAt(3);
        } else {
          b[83] = 0x00;
        }
        if(resourceName.length() > 4) {
          b[84] = (byte) resourceName.charAt(4);
        } else {
          b[84] = 0x00;
        }
        if(resourceName.length() > 5) {
          b[85] = (byte) resourceName.charAt(5);
        } else {
          b[85] = 0x00;
        }
        if(resourceName.length() > 6) {
          b[86] = (byte) resourceName.charAt(6);
        } else {
          b[86] = 0x00;
        }
        if(resourceName.length() > 7) {
          b[87] = (byte) resourceName.charAt(7);
        } else {
          b[87] = 0x00;
        }
        if(fName.length() > 0) {
          b[88] = (byte) fName.charAt(0);
        } else {
          b[88] = 0x20;
        }
        if(fName.length() > 1) {
          b[89] = (byte) fName.charAt(1);
        } else {
          b[89] = 0x20;
        }
        if(fName.length() > 2) {
          b[90] = (byte) fName.charAt(2);
        } else {
          b[90] = 0x20;
        }
        if(fName.length() > 3) {
          b[91] = (byte) fName.charAt(3);
        } else {
          b[91] = 0x20;
        }
        if(fName.length() > 4) {
          b[92] = (byte) fName.charAt(4);
        } else {
          b[92] = 0x20;
        }
        if(fName.length() > 5) {
          b[93] = (byte) fName.charAt(5);
        } else {
          b[93] = 0x20;
        }
        if(fName.length() > 6) {
          b[94] = (byte) fName.charAt(6);
        } else {
          b[94] = 0x20;
        }
        if(fName.length() > 7) {
          b[95] = (byte) fName.charAt(7);
        } else {
          b[95] = 0x20;
        }
        if(fName.length() > 8) {
          b[96] = (byte) fName.charAt(8);
        } else {
          b[96] = 0x20;
        }
        if(fName.length() > 9) {
          b[97] = (byte) fName.charAt(9);
        } else {
          b[97] = 0x20;
        }
        if(fName.length() > 10) {
          b[98] = (byte) fName.charAt(10);
        } else {
          b[98] = 0x20;
        }
        if(fName.length() > 11) {
          b[99] = (byte) fName.charAt(11);
        } else {
          b[99] = 0x20;
        }
        b[100] = 0x03;
        b[101] = 0x00;
        b[102] = 0x00;
        b[103] = 0x00;
        b[104] = 0x00;
        b[105] = 0x18;
        b[106] = 0x00;
        b[107] = 0x00;

        vmicout.write(b);

        vmicout.close();

        statusBar.setText("Output to "+vms.getName());
      } catch (IOException ex) {
        statusBar.setText("Failed");
      }
    }
  }

  //File | Exit action performed
  public void fileExit_actionPerformed(ActionEvent e) {
    statusBar.setText("Exiting");
    System.exit(0);
  }

  //File | Save action performed
  public void fileSave_actionPerformed(ActionEvent e) {
    jTable1.editingStopped(null);
    if(file != null) {
      try {
        PrintWriter cout = new PrintWriter(new BufferedWriter(new FileWriter(file)));
        for(int i = 0; i < 64; i++) {
          String [] data = db.getDataRow(i);
          String str = "";
          if(data != null) {
            if(data[0] != null) str = str + data[0];
            if(data[1] != null) str = str + "|"+data[1];
            if(data[2] != null) str = str + "|"+data[2];
            if(data[3] != null) str = str + "|"+data[3];
            if(!str.equals("")) {
              cout.println(str);
            }
          }
        }
        cout.close();
        statusBar.setText("File Saved As "+file.getName());
      } catch (IOException ex) {
        // Problem
        statusBar.setText("Failed");
      }
    } else {
      JFileChooser chooser = new JFileChooser();
      int returnVal = chooser.showSaveDialog(this);
      if(returnVal == JFileChooser.APPROVE_OPTION) {
        file = chooser.getSelectedFile();
        try {
          PrintWriter cout = new PrintWriter(new BufferedWriter(new FileWriter(file)));
          for(int i = 0; i < 64; i++) {
            String [] data = db.getDataRow(i);
            String str = "";
            if(data != null) {
              if(data[0] != null) str = str + data[0];
              if(data[1] != null) str = str + "|"+data[1];
              if(data[2] != null) str = str + "|"+data[2];
              if(data[3] != null) str = str + "|"+data[3];
              if(!str.equals("")) {
                cout.println(str);
              }
            }
          }
          cout.close();
          statusBar.setText("File Saved As "+file.getName());
        } catch (IOException ex) {
          //Problem
          statusBar.setText("Failed");
        }
      }
    }
  }

  //File | New action performed
  public void fileNew_actionPerformed(ActionEvent e) {
    jTable1.editingStopped(null);
    db.clear();
    file = null;
    statusBar.setText("New File");
    db.fireTableDataChanged();
  }

  //File | Open action performed
  public void fileOpen_actionPerformed(ActionEvent e) {
    jTable1.editingStopped(null);
    JFileChooser chooser = new JFileChooser();
    int returnVal = chooser.showOpenDialog(this);
    if(returnVal == JFileChooser.APPROVE_OPTION) {
      db.clear();
      db.fireTableDataChanged();
      file = chooser.getSelectedFile();
      BufferedReader reader = null;
      try {
        reader = new BufferedReader(new FileReader(file));
      } catch(FileNotFoundException fnfe) {
        // Problem ??
        statusBar.setText("Failed");
        return;
      }

      String value = null;
      int index = 0;
      try {
        while((value = reader.readLine()) != null) {
          StringTokenizer t = new StringTokenizer(value,"|");
          String [] data = new String [4];
          try {
            data[0] = t.nextToken();
            if(data[0].length() >6) data[0] = data[0].substring(0,6);
            data[1] = t.nextToken();
            if(data[1].length() >6) data[1] = data[1].substring(0,6);
            data[2] = t.nextToken();
            if(data[2].length() >6) data[2] = data[2].substring(0,6);
            data[3] = t.nextToken();
            if(data[3].length() >6) data[3] = data[3].substring(0,6);
          } catch(NoSuchElementException ex) {
          }
          db.setDataRow(index++,data);
        }
        reader.close();
        statusBar.setText("File Opened As "+file.getName());
        db.fireTableDataChanged();
      } catch(IOException ex) {
        // Problem ??
        statusBar.setText("Failed");
      }
    }
  }

  //File | Save As action performed
  public void fileSaveAs_actionPerformed(ActionEvent e) {
    jTable1.editingStopped(null);
    JFileChooser chooser = new JFileChooser();
    int returnVal = chooser.showSaveDialog(this);
    if(returnVal == JFileChooser.APPROVE_OPTION) {
      file = chooser.getSelectedFile();
      try {
        PrintWriter cout = new PrintWriter(new BufferedWriter(new FileWriter(file)));
        for(int i = 0; i < 64; i++) {
          String [] data = db.getDataRow(i);
          String str = "";
          if(data != null) {
            if(data[0] != null) str = str + data[0];
            if(data[1] != null) str = str + "|"+data[1];
            if(data[2] != null) str = str + "|"+data[2];
            if(data[3] != null) str = str + "|"+data[3];
            if(!str.equals("")) {
              cout.println(str);
            }
          }
        }
        cout.close();
        statusBar.setText("File Saved As "+file.getName());
      } catch (IOException ex) {
        //Problem
        statusBar.setText("Failed");
      }
    }
  }

  //Help | About action performed
  public void helpAbout_actionPerformed(ActionEvent e) {
    MainWindow_AboutBox dlg = new MainWindow_AboutBox(this);
    Dimension dlgSize = dlg.getPreferredSize();
    Dimension frmSize = getSize();
    Point loc = getLocation();
    dlg.setLocation((frmSize.width - dlgSize.width) / 2 + loc.x, (frmSize.height - dlgSize.height) / 2 + loc.y);
    dlg.setModal(true);
    dlg.show();
  }

  //Overridden so we can exit on System Close
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if(e.getID() == WindowEvent.WINDOW_CLOSING) {
      fileExit_actionPerformed(null);
    }
  }
}