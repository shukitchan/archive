package vmdb;

import javax.swing.text.*;
public class SixCharDocument extends PlainDocument {

  public void insertString(int offs, String str, AttributeSet a)
    throws BadLocationException {
    if(offs >= 6) return;
    super.insertString(offs, str,a);

  }
}