package vmdb;

import javax.swing.table.*;

public class DBModel extends AbstractTableModel {

  String [][] data = new String[64][4];
  String [] columnName = {"Record","Data 1","Data 2","Data 3","Data 4"};

  public DBModel() {
    data = new String[64][4];
  }

  public void clear() {
    data = new String[64][4];
  }

  public String [] getDataRow(int i) {
    return data[i];
  }

  public void setDataRow(int i, String [] dataRow) {
    data[i] = dataRow;
  }

  public boolean isCellEditable(int row, int column) {
    if(column == 0) {
      return false;
    } else {
  	  return true;
    }
  }

  public Object getValueAt(int row, int column) {
    if(column == 0) {
      return ""+(row+1);
    } else {
      String value = data[row][column-1];
      if(value == null) {
        return "";
      } else {
        return value;
      }
    }
  }

  public void setValueAt(Object obj, int row, int column) {
    if(column != 0) {
      data[row][column-1] = (String) obj;
    }
    fireTableCellUpdated(row,column);
  }

  public int getRowCount() {
    return 64;
  }

  public int getColumnCount() {
    return 5;
  }

  public String getColumnName(int column) {
    return columnName[column];
  }

  public Class getColumnClass(int columnIndex) {
    if(columnIndex == 0) {
      return Object.class;
    } else {
      return String.class;
    }
  }
}