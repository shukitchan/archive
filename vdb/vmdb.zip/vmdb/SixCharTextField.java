package vmdb;

import javax.swing.text.*;
import javax.swing.*;

public class SixCharTextField extends JTextField {

  protected Document createDefaultModel() {
    return new SixCharDocument();
  }
} 