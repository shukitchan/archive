/* map.c
 * This file implements map.h
 */

#include <glut.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "map.h"
#include "objects.h"

// init 2D perpective
void Set2DProjection(int g_Width, int g_Height) {
  glViewport(0, 0, g_Width, g_Height);
  glDisable(GL_LIGHTING);

  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  gluOrtho2D(0,g_Width,0,g_Height);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
}

// rollback to 3D perpective
void Set3DProjection(int g_Width, int g_Height, float g_nearPlane, float g_farPlane) {

  glViewport(0, 0, g_Width, g_Height);
  glEnable(GL_LIGHTING);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  gluPerspective(65.0, (float)g_Width / g_Height, g_nearPlane, g_farPlane);
  glMatrixMode(GL_MODELVIEW);
}

// draw the map, scale according to screen size
void DrawGrid(int g_Width, int g_Height) {
  int i, j, c;
  int mw,mh;
  int ri, rj;
  unsigned char * mapImage;

  glPushMatrix();
  glTranslatef(0.0,0.0,0.9);

  mapImage = (char*) malloc(sizeof(char) * (4*(g_Height/4+1)*(g_Width/4+1)));
  //unsigned char mapImage[(g_Height/4)+1][g_Width/4+1][4];
  mw = g_Width/4;
  mh = g_Height/4;
   
  for(i = 0 ; i <= mh; i++) {
    for(j = 0; j <= mw; j++) {
      ri = i % (g_Height/40); 
      rj = j % (g_Width/40);
      if((ri == 0)||(rj == 0)) {
        mapImage[(i*(mw+1)*4)+(j*4)+0] = (unsigned char) 255;
        mapImage[(i*(mw+1)*4)+(j*4)+1] = (unsigned char) 0;
        mapImage[(i*(mw+1)*4)+(j*4)+2] = (unsigned char) 0;
        mapImage[(i*(mw+1)*4)+(j*4)+3] = (unsigned char) 255;

        //mapImage[i][j][0] = (unsigned char) 255;
        //mapImage[i][j][1] = (unsigned char) 0;
        //mapImage[i][j][2] = (unsigned char) 0;
        //mapImage[i][j][3] = (unsigned char) 255;
      } else {
        mapImage[(i*(mw+1)*4)+(j*4)+0] = (unsigned char) 0;
        mapImage[(i*(mw+1)*4)+(j*4)+1] = (unsigned char) 0;
        mapImage[(i*(mw+1)*4)+(j*4)+2] = (unsigned char) 0;
        mapImage[(i*(mw+1)*4)+(j*4)+3] = (unsigned char) 0;

        //mapImage[i][j][0] = (unsigned char) 0;
        //mapImage[i][j][1] = (unsigned char) 0;
        //mapImage[i][j][2] = (unsigned char) 0;
        //mapImage[i][j][3] = (unsigned char) 0;
      }
    }
  }
  glPixelStorei(GL_UNPACK_ALIGNMENT,1);
  glRasterPos2i(0,g_Height-mh-1);
  glDrawPixels(mw+1,mh+1,GL_RGBA,GL_UNSIGNED_BYTE, mapImage);

  free(mapImage);

  glPopMatrix();
}

// draw the position and orientation of vehicle as arrow on map
void DrawArrow(float x, float y, float orientation) {
  float cv[3] = {1.0,0.0,0.0};
  glPushMatrix();
  glTranslatef(x,y,0.9);
  glRotatef(orientation,0.0,0.0,1.0);
  glColor3fv(cv);
  glBegin(GL_POLYGON);
    glVertex2f(0,10);glVertex2f(10,0);glVertex2f(5,0);
    glVertex2f(5,-10);glVertex2f(-5,-10);glVertex2f(-5,0);
    glVertex2f(-10,0);
  glEnd();
  glPopMatrix();
}

// Draw the active pole as a spot on map
void DrawSpot(float x, float y) {
  float cv[3] = {0.5,0.5,1.0};
  glPushMatrix();
  glTranslatef(x,y,0.9);
  glColor3fv(cv);
  glBegin(GL_POLYGON);
    glVertex2f(-10,0);
    glVertex2f(0,-10);
    glVertex2f(10,0);
    glVertex2f(0,10);
    //glVertex2f(0,10);glVertex2f(10,0);glVertex2f(0,-10);glVertex2f(-10,0);
  glEnd();
  glPopMatrix();
}

// draw the spot and arrow after translation
void Draw2DObjects(int g_Width,int g_Height) {
  int mh,mw;
  int p;
  float vi,vj,pi,pj;
  float orient;

  mh = g_Height/4;
  mw = g_Width/4;

  glPushMatrix();
  glTranslatef(0,g_Height-mh-1,0);
  // veh cal
  vi = ((game->vehicle[SELF].x / 1000.0) * (mh+1));
  vj = ((game->vehicle[SELF].y / 1000.0) * (mw+1));
  orient = game->vehicle[SELF].orientation - 90.0;
  DrawArrow(vj,mh+1-vi,orient);  

  //pole cal 
  if(game->activePole[SELF] >= game->numPole) {
    p = game->numPole-1;
  } else {
    p = game->activePole[SELF];
  }
  pi = ((game->poles[p].x / 1000.0) * (mh+1));
  pj = ((game->poles[p].y / 1000.0) * (mw+1));
  DrawSpot(pj,mh+1-pi);
  
  glPopMatrix();
}

// Draw the map, arrow and spot
void Draw2DMap(int g_Width,int g_Height) {
  Draw2DObjects(g_Width,g_Height);
  DrawGrid(g_Width,g_Height);
}

// draw a gauge
// need the value between 0.0 and 1.0
// also need the gauge color 
// the gauge will scale according to screen size
void Draw2DGauge(int g_Width, int g_Height, float value, int r, int g, int b) {
  int mw, gh;
  int i, j;
  float cvalue;
  unsigned char * gaugeImage;
  gaugeImage = (char *)malloc(sizeof(char) * (4 * (g_Height/16+1) * (g_Width/4+1)));
  //unsigned char gaugeImage[g_Height/16+1][g_Width/4+1][4];

  mw = g_Width/4;
  gh = g_Height/16;

  for(i =0;i <mw+1;i++) {
    for(j = 0; j < gh+1;j++) {
      if((i==0)||(j==0)||(i==mw)||(j==gh)) {
        gaugeImage[(j*(mw+1)*4)+(i*4)+0] = r;
        gaugeImage[(j*(mw+1)*4)+(i*4)+1] = g;
        gaugeImage[(j*(mw+1)*4)+(i*4)+2] = b;
        gaugeImage[(j*(mw+1)*4)+(i*4)+3] = 255;

        //gaugeImage[j][i][0] = r;
        //gaugeImage[j][i][1] = g;
        //gaugeImage[j][i][2] = b;
        //gaugeImage[j][i][3] = 255;
      } else {
        cvalue = ((float)i/(float)mw);
        if(cvalue > value) {
          gaugeImage[(j*(mw+1)*4)+(i*4)+0] = 0;
          gaugeImage[(j*(mw+1)*4)+(i*4)+1] = 0;
          gaugeImage[(j*(mw+1)*4)+(i*4)+2] = 0;
          gaugeImage[(j*(mw+1)*4)+(i*4)+3] = 0;  

          //gaugeImage[j][i][0] = 0;
          //gaugeImage[j][i][1] = 0;
          //gaugeImage[j][i][2] = 0;
          //gaugeImage[j][i][3] = 0;  
        } else {
          gaugeImage[(j*(mw+1)*4)+(i*4)+0] = (unsigned char) (cvalue * r);
          gaugeImage[(j*(mw+1)*4)+(i*4)+1] = (unsigned char) (cvalue * g);
          gaugeImage[(j*(mw+1)*4)+(i*4)+2] = (unsigned char) (cvalue * b);
          gaugeImage[(j*(mw+1)*4)+(i*4)+3] = 255;

          //gaugeImage[j][i][0] = (unsigned char) (cvalue * r);
          //gaugeImage[j][i][1] = (unsigned char) (cvalue * g);
          //gaugeImage[j][i][2] = (unsigned char) (cvalue * b);
          //gaugeImage[j][i][3] = 255;
        }
      }
    }
  }
  glPixelStorei(GL_UNPACK_ALIGNMENT,1);
  glDrawPixels(mw+1,gh+1,GL_RGBA,GL_UNSIGNED_BYTE, gaugeImage);

  free(gaugeImage);
}

// output character on screen
void output(char *text) { 
  char *p; 
  for (p = text; *p; p++) {
    glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, *p); 
  }
} 

// draw game parameter on screen
void DrawParams(int g_Width,int g_Height) {
  int gw,gh,mw,mh;

  glPushMatrix();
  glTranslatef(0.0,0.0,0.9);

  mw = g_Width/4;
  mh = g_Height/4;
  //gw = g_Width/16;
  gh = g_Height/16;

  // vehicle speed  
  glRasterPos2i(0,g_Height-mh-1-gh-1);
  Draw2DGauge(g_Width,g_Height,(game->vehicle[SELF].velocity/MAX_SPEED),255,255,0);
  glRasterPos2i(mw+1,g_Height-mh-1-gh-1);
  output("Speed");

  // your game progress
  glRasterPos2i(0,g_Height-mh-1-gh-1-gh-1);
  Draw2DGauge(g_Width, g_Height,((float)game->activePole[SELF]/(float)game->numPole),
              0,255,0);
  glRasterPos2i(mw+1,g_Height-mh-1-gh-1-gh-1);
  output("Your Progress");

  // your enemy progress
  glRasterPos2i(0,g_Height-mh-1-gh-1-gh-1-gh-1);
  Draw2DGauge(g_Width, g_Height,((float)game->activePole[ENEMY]/(float)game->numPole),
              0,0,255);
  glRasterPos2i(mw+1,g_Height-mh-1-gh-1-gh-1-gh-1);
  output("Enemy Progress");

  glPopMatrix();
}

// Draw the 2D map and game parameters 
void OldDraw2D(int w, int h) {
  Draw2DMap(w,h);
  glColor3f(1.0,1.0,1.0);
  DrawParams(w,h);
}

void Draw2D(int w, int h) {
    
}




