/* particle.h
 * Defines the data structures and objects for particle system
 */

#ifndef _PARTICLE_H
#define _PARTICLE_H

#define MAX_PARTICLE 1000
#define MAX_PARTICLE_SYSTEM 4 
#define TEXTURE_SIZE 64
#define COLOR_SIZE 4

// particle
typedef struct {
  float x;
  float y;
  float z;

  float xspeed;
  float yspeed;
  float zspeed;

  float energy;
  float fade;
} Particle;

// particle system
typedef struct {
  float xpull;
  float ypull;
  float zpull;

  float initXspeed;
  float initYspeed;
  float initZspeed;

  float initX;
  float initY;
  float initZ;

  float initEnergy;

  Particle particles[MAX_PARTICLE];

  int active;

  int numOfParticles;

  float size;
  unsigned char textureArray[TEXTURE_SIZE][TEXTURE_SIZE][COLOR_SIZE];
} ParticleSystem;

// particle manager
typedef struct {
  int numOfSystems;
  ParticleSystem * particleSystems[MAX_PARTICLE_SYSTEM];
} ParticleManager;

extern ParticleManager * particleManager;

void InitParticleManager(void);
int InitParticleSystem(void);
void UpdateParticles(float dt);
void FreeParticleManager(void);
void FreeParticleSystem(int system);

#endif
