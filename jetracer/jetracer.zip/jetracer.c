// jetracer.c
// Main file for the video game program
//

#include <glut.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/timeb.h>
#include <math.h>
#include "texture.h"
#include "glm.h"
#include "random.h"
#include "objects.h"
#include "map.h"
#include "smoke.h"
#include "particle.h"

// pole status color
#define INACTIVE 0
#define SELF_ACTIVE 1
#define ENEMY_ACTIVE 2 

// texture variables
#define WALL_TEXTURE 3
#define FLOOR_TEXTURE 4

#define ORIGINAL_WIDTH 800
#define ORIGINAL_HEIGHT 600

GLMmodel* vmodel = NULL;
GLMmodel* pmodel = NULL;

// calculate the elapse time for idle
struct timeb last_idle_time;

// turning map feature on
int mapOn = 1;

// size of game screen
int g_Width = 800;                 
int g_Height = 600; 

// DL
GLuint vehicleDL;
GLuint shieldDL;
GLuint normalPoleDL;
GLuint selfPoleDL;
GLuint enemyPoleDL;
GLuint arenaDL;
GLuint SelfVehicle2DDL;
GLuint EnemyVehicle2DDL;
GLuint SelfPole2DDL;
GLuint EnemyPole2DDL;
GLuint Plain2DDL;

// frustum related variables
const GLfloat g_nearPlane = 1;
const GLfloat g_farPlane = 1500;

// both are directional
const float g_lightPos0[4] = { 1, 1, 1, 0.0 };
const float g_lightPos1[4] = { -1, -1, 1, 0.0 };
const float g_lightDColor[4] = {1.0,1.0,1.0,1.0};
const float g_lightAColor[4] = {0.5,0.5,0.5,1.0};

// color for pole
const float g_selfPlateColor[4] = {1.0,0.2,0.0,0.6}; 
const float g_enemyPlateColor[4] = {0.5,0.5,0.0,0.6}; 
const float g_normalPlateColor[4] = {0.2,1.0,0.2,0.6};
const float g_poleColor[4] = {0.7,0.7,0.7,1.0};

// color for shield
const float g_sphereColor[4] = {0.2,0.2,0.7,0.3};

// shadow color
const float shadowColor[4] = {0.0,0.0,0.0,0.5};


// matrix for shadow : 
// 1000   1      1
// 0100 x 1   =  1 
// 0000   1      0 
// 0001   1      1
const float shadowMatrix1[16] = {1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1};

// floor & wall coord
const float floorTexV1[2] = {0.0,0.0};
const float floorTexV2[2] = {0.0,16.0};
const float floorTexV3[2] = {16.0,16.0};
const float floorTexV4[2] = {16.0,0.0};
const float floorVerV1[2] = {0.0,0.0};
const float floorVerV2[2] = {0.0,1000.0};
const float floorVerV3[2] = {1000.0,1000.0};
const float floorVerV4[2] = {1000.0,0.0};
 
const float wallTexV1[2] = {0.0,0.0};
const float wallTexV2[2] = {0.0,140.0};
const float wallTexV3[2] = {1.0,140.0};
const float wallTexV4[2] = {1.0,0.0};
const float wallTexV5[2] = {0.0,0.0};
const float wallTexV6[2] = {0.0,140.0};
const float wallTexV7[2] = {20.0,140.0};
const float wallTexV8[2] = {20.0,0.0};

const float lwallVerV1[3] = {0.0,-200.0,0.0};
const float lwallVerV2[3] = {0.0,1200.0,0.0};
const float lwallVerV3[3] = {0.0,1200.0,10.0};
const float lwallVerV4[3] = {0.0,-200.0,10.0};
const float lwallVerV5[3] = {0.0,-200.0,10.0};
const float lwallVerV6[3] = {0.0,1200.0,10.0};
const float lwallVerV7[3] = {-200.0,1200.0,10.0};
const float lwallVerV8[3] = {-200.0,-200.0,10.0};

const float bwallVerV1[3] = {-200.0,0.0,0.0};
const float bwallVerV2[3] = {1200.0,0.0,0.0};
const float bwallVerV3[3] = {1200.0,0.0,10.0};
const float bwallVerV4[3] = {-200.0,0.0,10.0};
const float bwallVerV5[3] = {-200.0,0.0,10.0};
const float bwallVerV6[3] = {1200.0,0.0,10.0};
const float bwallVerV7[3] = {1200.0,-200.0,10.0};
const float bwallVerV8[3] = {-200.0,-200.0,10.0};

const float rwallVerV1[3] = {1000.0,-200.0,0.0};
const float rwallVerV2[3] = {1000.0,1200.0,0.0};
const float rwallVerV3[3] = {1000.0,1200.0,10.0};
const float rwallVerV4[3] = {1000.0,-200.0,10.0};
const float rwallVerV5[3] = {1000.0,-200.0,10.0};
const float rwallVerV6[3] = {1000.0,1200.0,10.0};
const float rwallVerV7[3] = {1200.0,1200.0,10.0};
const float rwallVerV8[3] = {1200.0,-200.0,10.0};

const float twallVerV1[3] = {-200.0,1000.0,0.0};
const float twallVerV2[3] = {1200.0,1000.0,0.0};
const float twallVerV3[3] = {1200.0,1000.0,10.0};
const float twallVerV4[3] = {-200.0,1000.0,10.0};
const float twallVerV5[3] = {-200.0,1000.0,10.0};
const float twallVerV6[3] = {1200.0,1000.0,10.0};
const float twallVerV7[3] = {1200.0,1200.0,10.0};
const float twallVerV8[3] = {-200.0,1200.0,10.0};

void CreateLists(void) {
  Plain2DDL = glGenLists(1);
  glNewList(Plain2DDL,GL_COMPILE);
    glColor4f(0.5,0.5,0.5,0.5);
    glBegin(GL_POLYGON);
      glVertex2f(0,0);
      glVertex2f(0,(ORIGINAL_HEIGHT/4));
      glVertex2f((ORIGINAL_WIDTH/4),(ORIGINAL_HEIGHT/4));
      glVertex2f((ORIGINAL_WIDTH/4),0);
    glEnd();
  glEndList();

  SelfVehicle2DDL = glGenLists(1);
  glNewList(SelfVehicle2DDL,GL_COMPILE);
    glColor3f(1.0,0.2,0.0);
    glBegin(GL_POLYGON);
      glVertex2f(0,5);
      glVertex2f(-5,-5);
      glVertex2f(5,-5);
    glEnd();
  glEndList();

  EnemyVehicle2DDL = glGenLists(1);
  glNewList(EnemyVehicle2DDL,GL_COMPILE);
    glColor3f(0.5,0.5,0.0);
    glBegin(GL_POLYGON);
      glVertex2f(0,5);
      glVertex2f(-5,-5);
      glVertex2f(5,-5);
    glEnd();
  glEndList();
  
  SelfPole2DDL = glGenLists(1);
  glNewList(SelfPole2DDL, GL_COMPILE);
    glColor3f(1.0,0.2,0.0);
    glBegin(GL_POLYGON);
      glVertex2f(-5,-5);
      glVertex2f(-5,5);
      glVertex2f(5,5);
      glVertex2f(5,-5);
    glEnd();
  glEndList();

  EnemyPole2DDL = glGenLists(1);
  glNewList(EnemyPole2DDL, GL_COMPILE);
    glColor3f(0.5,0.5,0.0);
    glBegin(GL_POLYGON);
      glVertex2f(-5,-5);
      glVertex2f(-5,5);
      glVertex2f(5,5);
      glVertex2f(5,-5);
    glEnd();
  glEndList();

  vehicleDL = glGenLists(1);
  glNewList(vehicleDL,GL_COMPILE);
    glPushMatrix();
    glTranslatef(0.0,0.0,5.0);
    glmDraw(vmodel, GLM_SMOOTH | GLM_MATERIAL);
    glPopMatrix();
  glEndList();
  shieldDL = glGenLists(1);
  glNewList(shieldDL,GL_COMPILE);
    glPushMatrix();
    glTranslatef(0.0,0.0,7.0);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, g_sphereColor);
    glutSolidSphere(10.0,20,16);
    glPopMatrix();
  glEndList();
  normalPoleDL = glGenLists(1);
  glNewList(normalPoleDL,GL_COMPILE);
    glPushMatrix();
    glMaterialfv(GL_FRONT, GL_DIFFUSE, g_poleColor);
    glTranslatef(0,0,0);
    glutSolidCone(3.0,3,20,16);
    glPopMatrix();
    
    glPushMatrix();
    glTranslatef(0,0,25);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, g_normalPlateColor);
    glutSolidSphere(3.0,20,16);
    glPopMatrix();

    glPushMatrix();
    glTranslatef(0,0,10);
    glRotatef(90.0,1.0,0.0,0.0);
    glmDraw(pmodel, GLM_SMOOTH | GLM_MATERIAL);
    glPopMatrix();
  glEndList();
  selfPoleDL = glGenLists(1);
  glNewList(selfPoleDL,GL_COMPILE);
    glPushMatrix();
    glMaterialfv(GL_FRONT, GL_DIFFUSE, g_poleColor);
    glTranslatef(0,0,0);
    glutSolidCone(3.0,3,20,16);
    glPopMatrix();
    
    glPushMatrix();
    glTranslatef(0,0,25);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, g_selfPlateColor);
    glutSolidSphere(3.0,20,16);
    glPopMatrix();

    glPushMatrix();
    glTranslatef(0,0,10);
    glRotatef(90.0,1.0,0.0,0.0);
    glmDraw(pmodel, GLM_SMOOTH | GLM_MATERIAL);
    glPopMatrix();
  glEndList();
  enemyPoleDL = glGenLists(1);
  glNewList(enemyPoleDL,GL_COMPILE);
    glPushMatrix();
    glMaterialfv(GL_FRONT, GL_DIFFUSE, g_poleColor);
    glTranslatef(0,0,0);
    glutSolidCone(3.0,3,20,16);
    glPopMatrix();
    
    glPushMatrix();
    glTranslatef(0,0,25);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, g_enemyPlateColor);
    glutSolidSphere(3.0,20,16);
    glPopMatrix();

    glPushMatrix();
    glTranslatef(0,0,10);
    glRotatef(90.0,1.0,0.0,0.0);
    glmDraw(pmodel, GLM_SMOOTH | GLM_MATERIAL);
    glPopMatrix();
  glEndList();
  arenaDL = glGenLists(1);
  glNewList(arenaDL,GL_COMPILE);
  // floor
  glEnable(GL_TEXTURE_2D); 
  glBindTexture(GL_TEXTURE_2D,FLOOR_TEXTURE);
  glBegin(GL_POLYGON);
    glTexCoord2fv(floorTexV1);glVertex2fv(floorVerV1);
    glTexCoord2fv(floorTexV2);glVertex2fv(floorVerV2);
    glTexCoord2fv(floorTexV3);glVertex2fv(floorVerV3);
    glTexCoord2fv(floorTexV4);glVertex2fv(floorVerV4);
  glEnd();
  glDisable(GL_TEXTURE_2D);

  // wall
  glEnable(GL_TEXTURE_2D); 
  glBindTexture(GL_TEXTURE_2D,WALL_TEXTURE);
    glBegin(GL_POLYGON);
      glTexCoord2fv(wallTexV1);glVertex3fv(lwallVerV1);
      glTexCoord2fv(wallTexV2);glVertex3fv(lwallVerV2);
      glTexCoord2fv(wallTexV3);glVertex3fv(lwallVerV3);
      glTexCoord2fv(wallTexV4);glVertex3fv(lwallVerV4);
    glEnd();
    glBegin(GL_POLYGON);
      glTexCoord2fv(wallTexV5);glVertex3fv(lwallVerV5);
      glTexCoord2fv(wallTexV6);glVertex3fv(lwallVerV6);
      glTexCoord2fv(wallTexV7);glVertex3fv(lwallVerV7);
      glTexCoord2fv(wallTexV8);glVertex3fv(lwallVerV8);
    glEnd();
    glBegin(GL_POLYGON);
      glTexCoord2fv(wallTexV1);glVertex3fv(bwallVerV1);
      glTexCoord2fv(wallTexV2);glVertex3fv(bwallVerV2);
      glTexCoord2fv(wallTexV3);glVertex3fv(bwallVerV3);
      glTexCoord2fv(wallTexV4);glVertex3fv(bwallVerV4);
    glEnd();
    glBegin(GL_POLYGON);
      glTexCoord2fv(wallTexV5);glVertex3fv(bwallVerV5);
      glTexCoord2fv(wallTexV6);glVertex3fv(bwallVerV6);
      glTexCoord2fv(wallTexV7);glVertex3fv(bwallVerV7);
      glTexCoord2fv(wallTexV8);glVertex3fv(bwallVerV8);
    glEnd();
    glBegin(GL_POLYGON);
      glTexCoord2fv(wallTexV1);glVertex3fv(rwallVerV1);
      glTexCoord2fv(wallTexV2);glVertex3fv(rwallVerV2);
      glTexCoord2fv(wallTexV3);glVertex3fv(rwallVerV3);
      glTexCoord2fv(wallTexV4);glVertex3fv(rwallVerV4);
    glEnd();
    glBegin(GL_POLYGON);
      glTexCoord2fv(wallTexV5);glVertex3fv(rwallVerV5);
      glTexCoord2fv(wallTexV6);glVertex3fv(rwallVerV6);
      glTexCoord2fv(wallTexV7);glVertex3fv(rwallVerV7);
      glTexCoord2fv(wallTexV8);glVertex3fv(rwallVerV8);
    glEnd();
    glBegin(GL_POLYGON);
      glTexCoord2fv(wallTexV1);glVertex3fv(twallVerV1);
      glTexCoord2fv(wallTexV2);glVertex3fv(twallVerV2);
      glTexCoord2fv(wallTexV3);glVertex3fv(twallVerV3);
      glTexCoord2fv(wallTexV4);glVertex3fv(twallVerV4);
    glEnd();
    glBegin(GL_POLYGON);
      glTexCoord2fv(wallTexV5);glVertex3fv(twallVerV5);
      glTexCoord2fv(wallTexV6);glVertex3fv(twallVerV6);
      glTexCoord2fv(wallTexV7);glVertex3fv(twallVerV7);
      glTexCoord2fv(wallTexV8);glVertex3fv(twallVerV8);
    glEnd();
  glDisable(GL_TEXTURE_2D);
  glEndList();
}

// draw one pole
void DrawPole(float x, float y, int active) {
  glPushMatrix();
  glTranslatef(x,y,0);
  if(active == INACTIVE) {
    glCallList(normalPoleDL);
  } else if(active == SELF_ACTIVE) {
    glCallList(selfPoleDL);
  } else {
    glCallList(enemyPoleDL);
  }
  glPopMatrix();
}

// draw the smoke particles for the vehicles
void RenderParticles(int veh) {
  int i, j;
  ParticleSystem * ps;
  Particle p;
  float sinTheta;
  float cosTheta;
  
  // billboarding is used so particles always face the camera
  sinTheta = (float)sin(((double)game->vehicle[veh].orientation)/360*2*M_PI);
  cosTheta = (float)cos(((double)game->vehicle[veh].orientation)/360*2*M_PI);

  glEnable(GL_TEXTURE_2D);
  glBindTexture(GL_TEXTURE_2D, veh+1);
  for(j = 0; j < NUM_OF_EXHAUST; j++) {
    ps = particleManager->particleSystems[smokeSystem[j][veh]];
    for(i = 0; i < ps->numOfParticles;i++) {
      p = ps->particles[i];
      glBegin(GL_QUADS);
      glTexCoord2f(0.0,0.0);
      glVertex3f(p.x-(ps->size/2*cosTheta),p.y-(ps->size/2*sinTheta),
                 p.z-ps->size/2);
      glTexCoord2f(0.0,1.0);
      glVertex3f(p.x-(ps->size/2*cosTheta),p.y-(ps->size/2*sinTheta),
                 p.z+ps->size/2);
      glTexCoord2f(1.0,1.0);
      glVertex3f(p.x+(ps->size/2*cosTheta),p.y+(ps->size/2*sinTheta),
                 p.z+ps->size/2);
      glTexCoord2f(1.0,0.0);
      glVertex3f(p.x+(ps->size/2*cosTheta),p.y+(ps->size/2*sinTheta),
                 p.z-ps->size/2);  
      glEnd();
    }
  }
  glDisable(GL_TEXTURE_2D);
}

// draw all poles for the game
// using different color if pole is active for myself or enemy
void DrawPoles(void) {
  int i;
  for(i = 0; i < game->numPole;i++) {
    if(i == game->activePole[SELF]) {
      DrawPole(game->poles[i].x,game->poles[i].y,SELF_ACTIVE);
    } else if(i == game->activePole[ENEMY]){
      if(getGameMode() == GAME_MODE_DOUBLE) {
        DrawPole(game->poles[i].x,game->poles[i].y,ENEMY_ACTIVE);
      } else {
        DrawPole(game->poles[i].x,game->poles[i].y,INACTIVE);
      }
    } else {
      DrawPole(game->poles[i].x, game->poles[i].y, INACTIVE);
    }
  }
}

// draw both vehicles 
void DrawVehicles(void) {
  glPushMatrix();
  glTranslatef(game->vehicle[SELF].x,game->vehicle[SELF].y,0.0);
  glRotatef(game->vehicle[SELF].orientation,0.0,0.0,1.0);
  glCallList(vehicleDL);
  glPopMatrix();
 
  if(getGameMode() == GAME_MODE_DOUBLE){
    glPushMatrix();
    glTranslatef(game->vehicle[ENEMY].x,game->vehicle[ENEMY].y,0.0);
    glRotatef(game->vehicle[ENEMY].orientation,0.0,0.0,1.0);
    glCallList(vehicleDL);
    glPopMatrix();
  }
}

void DrawShields(void) {
  glPushMatrix();
  glTranslatef(game->vehicle[SELF].x,game->vehicle[SELF].y,0.0);
  glRotatef(game->vehicle[SELF].orientation,0.0,0.0,1.0);
  if(game->vehicle[SELF].shield) {
    glCallList(shieldDL);
  }
  glPopMatrix();
 
  if(getGameMode() == GAME_MODE_DOUBLE){
    glPushMatrix();
    glTranslatef(game->vehicle[ENEMY].x,game->vehicle[ENEMY].y,0.0);
    glRotatef(game->vehicle[ENEMY].orientation,0.0,0.0,1.0);
    if(game->vehicle[ENEMY].shield) {
      glCallList(shieldDL);
    }
    glPopMatrix();
  }
}

void RenderObjects(void) {
  glCallList(arenaDL);
  DrawPoles();
  DrawVehicles();

  RenderParticles(SELF);
  if(getGameMode() == GAME_MODE_DOUBLE) {
    RenderParticles(ENEMY);
  }

  // beginning to render shadow for all objects
  glEnable(GL_POLYGON_OFFSET_FILL);
  glDisable(GL_LIGHTING);
  glColor4fv(shadowColor);

  // light cast shadow on floor
  glPushMatrix();
  glMultMatrixf(shadowMatrix1);
  DrawPoles();
  DrawVehicles();
  glPopMatrix();

  glEnable(GL_LIGHTING);
  glDisable(GL_POLYGON_OFFSET_FILL);

  // render shields
  DrawShields();
}

// when screen is resized
void display(void) {
  float vpdist, ydelta, xdelta;
  double orient;
  float h;
  float xscale, yscale;
  float vectorX,vectorY,vectorX1, vectorY1;
  float radius, angle;
  int mh, i, slice;

  // clear necessary buffers
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);
  glLoadIdentity();

  // setting up camera 
  vpdist = g_farPlane;
  orient = (double)game->vehicle[SELF].orientation;
  ydelta = vpdist * cos((orient/360.0)*2*M_PI);
  xdelta = vpdist * sin((orient/360.0)*2*M_PI) * (-1);

  if(getCameraMode() == CAMERA_MODE_OVER) {
    h = CAMERA_HEIGHT;
  } else {
    h = 5;
  }

  gluLookAt(game->camera.x, game->camera.y, h, 
            game->vehicle[SELF].x + xdelta, game->vehicle[SELF].y + ydelta, 
            h, 0, 0, 1);

  // light
  glLightfv(GL_LIGHT0, GL_POSITION, g_lightPos0);
  glLightfv(GL_LIGHT0, GL_DIFFUSE, g_lightDColor);
  glLightfv(GL_LIGHT0, GL_AMBIENT, g_lightAColor);
  glLightfv(GL_LIGHT1, GL_POSITION, g_lightPos1);
  glLightfv(GL_LIGHT1, GL_DIFFUSE, g_lightDColor);
  glLightfv(GL_LIGHT1, GL_AMBIENT, g_lightAColor);

  // objects
  RenderObjects();

  // 2D projection map
  Set2DProjection(g_Width, g_Height);

  if(mapOn) {
    glPushMatrix();

    xscale = ((float)g_Width / (float)ORIGINAL_WIDTH);
    yscale = ((float)g_Height / (float)ORIGINAL_HEIGHT);

    glTranslatef(3.0,g_Height - 3 - ((ORIGINAL_HEIGHT/4) * yscale),0.9);
    glScalef(xscale, yscale, 1.0);

    glCallList(Plain2DDL);

    glPushMatrix();
      glTranslatef(game->poles[game->activePole[SELF]].x/1000*(ORIGINAL_WIDTH/4),
                   game->poles[game->activePole[SELF]].y/1000*(ORIGINAL_HEIGHT/4),0.05);
      glCallList(SelfPole2DDL);
    glPopMatrix();

    glPushMatrix();
      glTranslatef(game->vehicle[SELF].x/1000*(ORIGINAL_WIDTH/4),
                   game->vehicle[SELF].y/1000*(ORIGINAL_HEIGHT/4),0.05);
      glRotatef(game->vehicle[SELF].orientation,0.0,0.0,1.0);
      glCallList(SelfVehicle2DDL);
    glPopMatrix();

    if(getGameMode() == GAME_MODE_DOUBLE){
      glPushMatrix();
        glTranslatef(game->poles[game->activePole[ENEMY]].x/1000*(ORIGINAL_WIDTH/4),
                     game->poles[game->activePole[ENEMY]].y/1000*(ORIGINAL_HEIGHT/4),0.05);
        glCallList(EnemyPole2DDL);
      glPopMatrix();

      glPushMatrix();
        glTranslatef(game->vehicle[ENEMY].x/1000*(ORIGINAL_WIDTH/4),
                     game->vehicle[ENEMY].y/1000*(ORIGINAL_HEIGHT/4),0.05);
        glRotatef(game->vehicle[ENEMY].orientation,0.0,0.0,1.0);
        glCallList(EnemyVehicle2DDL);
      glPopMatrix();
    }

    glPopMatrix();
  }   
 
  radius = g_Height / 8;

  glColor3f(0.5,0.0,0.8);
  glPushMatrix();
    glTranslatef(g_Width - 3 - radius, 3 + radius, 0.9); 
    slice = (game->vehicle[SELF].velocity/MAX_SPEED)*360;
    vectorY1=0;
    vectorX1=0; 
    glBegin(GL_TRIANGLES);	
    for(i=0;i<=slice;i++) {
      angle=(float)(((double)i)/57.29577957795135);	
      vectorX=(radius*(float)sin((double)angle));
      vectorY=(radius*(float)cos((double)angle));		
      glVertex2d(0,0); 
      glVertex2d(vectorX1,vectorY1);
      glVertex2d(vectorX,vectorY);
      vectorY1=vectorY;
      vectorX1=vectorX;	
    }
    glEnd();
  glPopMatrix();

  glColor3f(1.0,0.2,0.5);
  glPushMatrix();
    glTranslatef(g_Width - 3 - radius, g_Height - 3 - radius, 0.9); 
    slice = ((float)game->activePole[SELF]/(float)NUM_OF_POLE)*360;
    vectorY1=0;
    vectorX1=0; 
    glBegin(GL_TRIANGLES);	
    for(i=0;i<=slice;i++) {
      angle=(float)(((double)i)/57.29577957795135);	
      vectorX=(radius*(float)sin((double)angle));
      vectorY=(radius*(float)cos((double)angle));		
      glVertex2d(0,0); 
      glVertex2d(vectorX1,vectorY1);
      glVertex2d(vectorX,vectorY);
      vectorY1=vectorY;
      vectorX1=vectorX;	
    }
    glEnd();
  glPopMatrix();

  if(getGameMode() == GAME_MODE_DOUBLE){
    glColor3f(0.5,0.5,0.0);
    glPushMatrix();
      glTranslatef(g_Width - 6 - (3*radius), g_Height - 3 - radius, 0.9); 
      slice = ((float)game->activePole[ENEMY]/(float)NUM_OF_POLE)*360;
      vectorY1=0;
      vectorX1=0; 
      glBegin(GL_TRIANGLES);	
      for(i=0;i<=slice;i++) {
        angle=(float)(((double)i)/57.29577957795135);	
        vectorX=(radius*(float)sin((double)angle));
        vectorY=(radius*(float)cos((double)angle));		
        glVertex2d(0,0); 
        glVertex2d(vectorX1,vectorY1);
        glVertex2d(vectorX,vectorY);
        vectorY1=vectorY;
        vectorX1=vectorX;	
      }
      glEnd();
    glPopMatrix();
  }

  Set3DProjection(g_Width, g_Height, g_nearPlane, g_farPlane);
 
  glutSwapBuffers();
}

void reshape(int w, int h) {
  g_Width = w;
  g_Height = h;
  
  glViewport(0,0,(GLsizei)w, (GLsizei)h);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  gluPerspective(65.0,(float)g_Width/g_Height,g_nearPlane,g_farPlane);
  glMatrixMode(GL_MODELVIEW);
}

// init graphics
void InitGraphics(void) {
  
  // enabling depth of field
  glEnable(GL_DEPTH_TEST);
  glDepthFunc(GL_LESS);

  // lighting
  glShadeModel(GL_SMOOTH);
  glEnable(GL_LIGHTING);
  glEnable(GL_LIGHT0);
  glEnable(GL_LIGHT1);
  
  // set clear color
  glClearColor(0.4,0.4,0.9,0.0);

  glEnable(GL_BLEND);
  glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

  // shadow related
  glPolygonOffset(-2.0,-1.0);
}

// idle function
void AnimateScene(void) {
  struct timeb time_now;
  float dt;

  // calculate elapsed time 
  ftime(&time_now);
  dt = (float)(time_now.time  - last_idle_time.time) +
       1.0e-3*(time_now.millitm - last_idle_time.millitm);
  //printf("dt:%f\n",dt);

  // update the game
  UpdateGame(dt);

  // update the particles
  if(getGameState() == GAME_STATE_RUNNING) {
    UpdateParticles(dt);
    UpdateSmokeSystem(SELF,EXHAUST_LEFT);
    UpdateSmokeSystem(SELF,EXHAUST_RIGHT);
    if(getGameMode() == GAME_MODE_DOUBLE) {
      UpdateSmokeSystem(ENEMY,EXHAUST_LEFT);
      UpdateSmokeSystem(ENEMY,EXHAUST_RIGHT);
    }
  }

  last_idle_time = time_now;

  glutPostRedisplay();
}

// key control
void Keyboard(unsigned char key, int x, int y) {
  switch (key) {
    case 27:             // ESCAPE key, exit
      exit (0);
      break;
    case 'i':            // Accelerate
      ControlChange(UP,ON,SELF);  
      break;
    case 'k':            // Decelerate
      ControlChange(DOWN,ON,SELF);  
      break;
    case 'j':            // left turn
      ControlChange(LEFT,ON,SELF);  
      break;
    case 'l' :           // right turn
      ControlChange(RIGHT,ON,SELF);  
      break; 
    case 'b' :           // start the game
      setGameState(GAME_STATE_RUNNING);
      break;
    case '1' :           // 1 player mode
      setGameMode(GAME_MODE_SINGLE);
      break;
    case '2' :           // 2 player mode
      setGameMode(GAME_MODE_DOUBLE);
      break;
    case 'c' :           // camera mode setting
      setCameraMode(1 - getCameraMode());
      break;
    case 'm' :           // map on or off
      mapOn = 1 - mapOn;
      break;
    case 'r' :           // reset the game
      InitGame();
      ResetSmokeSystem(SELF,EXHAUST_LEFT);
      ResetSmokeSystem(SELF,EXHAUST_RIGHT);
      ResetSmokeSystem(ENEMY,EXHAUST_LEFT);
      ResetSmokeSystem(ENEMY,EXHAUST_RIGHT);
      break;
  }
}

// for smooth control of vehicle action
void KeyboardUp(unsigned char key, int x, int y) {
  switch (key) {
    case 'i':  //End Accelerate
      ControlChange(UP,OFF,SELF);  
      break;
    case 'k':  // End Decelerate
      ControlChange(DOWN,OFF,SELF);  
      break;
    case 'j':  // End Left turn
      ControlChange(LEFT,OFF,SELF);  
      break;
    case 'l':  // End right turn
      ControlChange(RIGHT,OFF,SELF);
      break;
  }
}

// prepare texture for particles
void MakeTexture(int veh,int right) {
  ParticleSystem * ps = 
    particleManager->particleSystems[smokeSystem[right][veh]];
  glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
  glBindTexture(GL_TEXTURE_2D,veh+1);
  glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
  glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);
  glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,64,64,
               0,GL_RGBA,GL_UNSIGNED_BYTE,ps->textureArray);
  glTexEnvf(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,GL_REPLACE);
}

void PrepareTexture(void) {
  int width,height,nComponents;
  void * textureImage;

  // floor
  textureImage = read_texture("mech.rgb", &width, &height, &nComponents);
  glBindTexture(GL_TEXTURE_2D, FLOOR_TEXTURE);
  glTexParameterf (GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
  glTexParameterf (GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
  gluBuild2DMipmaps(GL_TEXTURE_2D,     // texture to specify
                    GL_RGBA,           // internal texture storage format
                    width,             // texture width
                    height,            // texture height
                    GL_RGBA,           // pixel format
                    GL_UNSIGNED_BYTE,	// color component format
                    textureImage);    // pointer to texture image
  glTexEnvf (GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
  free(textureImage);

  // wall
  textureImage = read_texture("PolishedMetal.rgb", &width, &height, &nComponents);
  glBindTexture(GL_TEXTURE_2D, WALL_TEXTURE);
  glTexParameterf (GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
  glTexParameterf (GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
  gluBuild2DMipmaps(GL_TEXTURE_2D,     // texture to specify
                    GL_RGBA,           // internal texture storage format
                    width,             // texture width
                    height,            // texture height
                    GL_RGBA,           // pixel format
                    GL_UNSIGNED_BYTE,	// color component format
                    textureImage);    // pointer to texture image
  glTexEnvf (GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
  free(textureImage);
}

// prepare objects
void MakeObjects(void) {
  vmodel = glmReadOBJ("shuttle.obj");
  glmUnitize(vmodel);
  glmScale(vmodel,120.0f);

  pmodel = glmReadOBJ("dish.obj");
  glmUnitize(pmodel);
  glmScale(pmodel,10.0f);
  glmFacetNormals(pmodel);
  glmVertexNormals(pmodel, 90.0);
}

int main(int argc, char** argv) {

  // GLUT Window Initialization:
  glutInit (&argc, argv);
  glutInitWindowSize(g_Width, g_Height);
  glutInitWindowPosition(100,100);
  glutInitDisplayMode ( GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);
  glutCreateWindow ("Jet Racer");

  // Initialize
  InitGraphics();
  initRandom();
  InitGame();

  // particle system
  InitParticleManager();
  InitSmokeSystem(SELF,EXHAUST_LEFT);
  InitSmokeSystem(SELF,EXHAUST_RIGHT);
  MakeTexture(SELF,EXHAUST_LEFT);
  MakeTexture(SELF,EXHAUST_RIGHT);
  InitSmokeSystem(ENEMY,EXHAUST_LEFT);
  InitSmokeSystem(ENEMY,EXHAUST_RIGHT);
  MakeTexture(ENEMY,EXHAUST_LEFT);
  MakeTexture(ENEMY,EXHAUST_RIGHT);

  PrepareTexture();
  MakeObjects();

  CreateLists();

  glutDisplayFunc(display);
  glutReshapeFunc(reshape);
  glutKeyboardFunc (Keyboard);
  glutKeyboardUpFunc(KeyboardUp);
  glutIdleFunc(AnimateScene);

  ftime(&last_idle_time);

  glutMainLoop ();
  return 0;
}

