/* random.h
 * Defines the routine for random number generation
 */

#ifndef _RANDOM_H
#define _RANDOM_H

void initRandom(void);
float randomInt(int range);
float randomFade(void);
float randomXspeed(void);
float randomYspeed(void);
float randomZspeed(void);

#endif
