/* ai.c
 * This file implements ai.h
 * This contains routine to determine the enemy vehicle action
 */

#include "ai.h"
#include "objects.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

// predict enemy vehicle action
void PredictEnemyAction(void) {
  float orientation;
  float direction;
  double theta;
  float different;
  float x1;
  float y1;
  float x2;
  float y2;

  // finding the orientation of enemy vehicle 
  // and the direction of the active pole for enemy
  orientation = game->vehicle[ENEMY].orientation;
  x1 = game->vehicle[ENEMY].x;
  y1 = game->vehicle[ENEMY].y;
  x2 = game->poles[game->activePole[ENEMY]].x;
  y2 = game->poles[game->activePole[ENEMY]].y;

  if((x1 > x2) &&(y2 > y1)) {
    theta = atan((double)((x1-x2)/(y2-y1)));
  } else if((x1 > x2) && (y1 > y2)) {
    theta = atan((double)((y1-y2)/(x1-x2))) + (M_PI_2);
  } else if((x2 > x1) && (y1 > y2)) {
    theta = atan((double)((x2-x1)/(y1-y2))) + (M_PI);
  } else if((x2 > x1) && (y2 > y1)) {
    theta = atan((double)((y2-y1)/(x2-x1))) + (3 * M_PI_2);
  } else if((y1 == y2)&&(x1 > x2)) {
    theta = M_PI_2;
  } else if((y1 == y2)&&(x2 > x1)) {
    theta = 3 * M_PI_2;
  } else if((x1 == x2)&&(y1 > y2)) {
    theta = M_PI;
  } else if((x1 == x2)&&(y2 >= y1)) {
    theta = 0;
  }

  direction = (float) ((theta / (2.0 * M_PI)) * 360.0);

  different = direction - orientation;
  if(different > 180) {
    different -= 360;
  } else if(different < -180) {
    different += 360;
  }

  // turn left or right based on the findings above
  // if the direction is almost right, accelerate
  // else decelerate
  if(different > 0){
    game->vehicle[ENEMY].controlFlag[LEFT] = ON;
    game->vehicle[ENEMY].controlFlag[RIGHT] = OFF;
    if(different > 10) {
      game->vehicle[ENEMY].controlFlag[UP] = OFF;
      game->vehicle[ENEMY].controlFlag[DOWN] = ON;
    } else {
      game->vehicle[ENEMY].controlFlag[UP] = ON;
      game->vehicle[ENEMY].controlFlag[DOWN] = OFF;
    }
  } else if(different < 0) {
    game->vehicle[ENEMY].controlFlag[LEFT] = OFF;
    game->vehicle[ENEMY].controlFlag[RIGHT] = ON;
    if(different < -10) {
      game->vehicle[ENEMY].controlFlag[UP] = OFF;
      game->vehicle[ENEMY].controlFlag[DOWN] = ON;
    } else {
      game->vehicle[ENEMY].controlFlag[UP] = ON;
      game->vehicle[ENEMY].controlFlag[DOWN] = OFF;
    }
  } else {
    game->vehicle[ENEMY].controlFlag[LEFT] = OFF;
    game->vehicle[ENEMY].controlFlag[RIGHT] = OFF;
    game->vehicle[ENEMY].controlFlag[UP] = ON;
    game->vehicle[ENEMY].controlFlag[DOWN] = OFF;
  }
}
