/* smoke.h
 * Defines the data structures and objects for vehicle smoke
 */
#include "objects.h"
#include "particle.h"

#ifndef _SMOKE_H
#define _SMOKE_H

#define ZPULL 0.0f
#define SMOKE_PULL -50
#define SMOKE_HEIGHT 4.5f

#define EXHAUST_LEFT 0
#define EXHAUST_RIGHT 1
#define NUM_OF_EXHAUST 2

#define VW 1.8f
#define VL 6

extern int smokeSystem[NUM_OF_EXHAUST][NUM_OF_VEH];

void InitSmokeSystem(int veh, int right);
void UpdateSmokeSystem(int veh, int right);
void ResetSmokeSystem(int veh, int right);

#endif
