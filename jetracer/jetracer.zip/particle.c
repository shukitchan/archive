/* particle.c
 * This file implements particle.h
 */

#include "particle.h"
#include "random.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

// starting point
ParticleManager * particleManager;

// free particle manager
void FreeParticleManager(void) {
  int i ;
  for(i  = 0; i < particleManager->numOfSystems;i++) {
    FreeParticleSystem(i);
  }
  free(particleManager);
}

// free particle system
void FreeParticleSystem(int system) {
  free(particleManager->particleSystems[system]);
}

// initialize particle manager
void InitParticleManager(void) {
  particleManager = (ParticleManager *)malloc(sizeof(ParticleManager));
  particleManager->numOfSystems = 0;
}

// initialize particle system
int InitParticleSystem(void) {
  int system;
  ParticleSystem * ps;

  system = particleManager->numOfSystems;
  particleManager->numOfSystems++;

  ps = (ParticleSystem *) malloc(sizeof(ParticleSystem));
  ps->numOfParticles = 0;
  ps->active = 0;
  particleManager->particleSystems[system] = ps;

  return system;
}

// update all particles in all system under the manager
void UpdateParticles(float dt) {
  int i,j;
  int np;
  ParticleSystem * ps;
  //Particle p;

  // all systems
  for(i = 0; i < particleManager->numOfSystems; i++) {
    ps = particleManager->particleSystems[i];
    if(ps->active) {
      np = ps->numOfParticles;
      // all particles
      for(j = 0; j < np; j++) {
        //p = ps->particles[j];
        if(ps->particles[j].energy > 0.0f) {
 
          ps->particles[j].x += ps->particles[j].xspeed * dt;
          ps->particles[j].y += ps->particles[j].yspeed * dt;
          ps->particles[j].z += ps->particles[j].zspeed * dt;
 
          ps->particles[j].xspeed += ps->xpull;
          ps->particles[j].yspeed += ps->ypull;
          ps->particles[j].zspeed += ps->zpull;

          ps->particles[j].energy -= ps->particles[j].fade;
        }

        // if particle dies, revive it
        if(ps->particles[j].energy < 0.0f) {
          ps->particles[j].energy = ps->initEnergy;
          ps->particles[j].fade = randomFade();
          ps->particles[j].x = ps->initX;
          ps->particles[j].y = ps->initY;
          ps->particles[j].z = ps->initZ;
          ps->particles[j].xspeed = ps->initXspeed + randomXspeed();
          ps->particles[j].yspeed = ps->initYspeed + randomYspeed();
          ps->particles[j].zspeed = ps->initZspeed + randomZspeed();
        }
      }
    }
  }
}

