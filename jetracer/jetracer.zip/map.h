/* map.h
 * Defines routine for drawing 2D map
 */

#ifndef _MAP_H
#define _MAP_H

void Set2DProjection(int g_Width, int g_Height);
void Draw2D(int g_Width,int g_Height);
void Set3DProjection(int g_Width, int g_Height, float g_nearPlane, float g_farPlane);

#endif
