/* random.c
 * This file implements random.h
 */

#include "random.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

// initialize random seed
void initRandom(void) {
  srand(time(NULL));
}

// random coordinate for poles
float randomInt(int range) {
  return ((float)(rand()%range) );
}

// random fade value for particles
float randomFade(void) {
  return 0.05 + ((float)(rand()%10))/1000;
}

// random speed in x direction for particles
float randomXspeed(void) {
  return (((float)(rand()%101)) - 50)/25;
}

// random speed in y direction for particles
float randomYspeed(void) {
  return (((float)(rand()%101)) - 50)/25;
}

// random speed in z direction for particles
float randomZspeed(void) {
  return (((float)(rand()%101)) - 50)/25;
}
