/* smoke.c
 * This file implements smoke.h
 */

#include "smoke.h"
#include "objects.h"
#include "particle.h"
#include "random.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

//smoke system containing particle system ID
int smokeSystem[NUM_OF_EXHAUST][NUM_OF_VEH];

// init smoke system
void InitSmokeSystem(int veh,int right) {
  ParticleSystem * ps;
  int i, j, c, ds , alpha;
  float dist;
  float rn;

  // get a particle system handle
  smokeSystem[right][veh] = InitParticleSystem();

  // system vars
  ps = particleManager->particleSystems[smokeSystem[right][veh]];
  ps->numOfParticles = MAX_PARTICLE;
  ds = TEXTURE_SIZE/2;
  // particle texture generation
  for(i=0;i < TEXTURE_SIZE; i++) {
    for(j = 0; j < TEXTURE_SIZE;j++) {
      dist = (i - ds) * (i - ds) + 
             (j - ds) * (j - ds);
      dist = (float) sqrt((double) dist);
      if(dist >= ds) {
        c = 0;
        alpha = 0;
      } else {
        c = 255;
        alpha = 255 - (((int)dist) * 256/((int)ds));
      }
      ps->textureArray[i][j][0] = c;
      ps->textureArray[i][j][1] = c;
      ps->textureArray[i][j][2] = c;
      ps->textureArray[i][j][3] = alpha;
    }
  } 
  ps->active = 1;
  ps->xpull = 0;
  ps->ypull = 0;
  ps->zpull = ZPULL;

  ps->initXspeed = (SMOKE_PULL)* (-1.0) *
    (float)sin(((double)game->vehicle[veh].orientation)/360*2*M_PI);
  ps->initYspeed = (SMOKE_PULL)* 
    (float)cos(((double)game->vehicle[veh].orientation)/360*2*M_PI);

  //ps->initXspeed = 0;
  //ps->initYspeed = SMOKE_PULL;
  ps->initZspeed = 0;

  // right exhaust or left exhaust
  // different init positions for particles
  if(right) {
    ps->initX = game->vehicle[veh].x + 
      ((float)sin(((double)game->vehicle[veh].orientation)/360*2*M_PI)*VL)+
      ((float)cos(((double)game->vehicle[veh].orientation)/360*2*M_PI)*VW);
    ps->initY = game->vehicle[veh].y -
      ((float)cos(((double)game->vehicle[veh].orientation)/360*2*M_PI)*VL)+
      ((float)sin(((double)game->vehicle[veh].orientation)/360*2*M_PI)*VW);
    ps->initZ = SMOKE_HEIGHT;
  } else {
    ps->initX = game->vehicle[veh].x + 
      ((float)sin(((double)game->vehicle[veh].orientation)/360*2*M_PI)*VL)-
      ((float)cos(((double)game->vehicle[veh].orientation)/360*2*M_PI)*VW);
    ps->initY = game->vehicle[veh].y -
      ((float)cos(((double)game->vehicle[veh].orientation)/360*2*M_PI)*VL)-
      ((float)sin(((double)game->vehicle[veh].orientation)/360*2*M_PI)*VW);
    ps->initZ = SMOKE_HEIGHT;
  }

  ps->initEnergy = 1;
  ps->size = 0.5;

  // particle vars
  for(i = 0; i < MAX_PARTICLE; i++) {
    if(right) {
      ps->particles[i].x = game->vehicle[veh].x +
        ((float)sin(((double)game->vehicle[veh].orientation)/360*2*M_PI)*VL)+
        ((float)cos(((double)game->vehicle[veh].orientation)/360*2*M_PI)*VW);
      ps->particles[i].y = game->vehicle[veh].y -
        ((float)cos(((double)game->vehicle[veh].orientation)/360*2*M_PI)*VL)+
        ((float)sin(((double)game->vehicle[veh].orientation)/360*2*M_PI)*VW);
      ps->particles[i].z = SMOKE_HEIGHT;
    } else {
      ps->particles[i].x = game->vehicle[veh].x +
        ((float)sin(((double)game->vehicle[veh].orientation)/360*2*M_PI)*VL)-
        ((float)cos(((double)game->vehicle[veh].orientation)/360*2*M_PI)*VW);
      ps->particles[i].y = game->vehicle[veh].y -
        ((float)cos(((double)game->vehicle[veh].orientation)/360*2*M_PI)*VL)-
        ((float)sin(((double)game->vehicle[veh].orientation)/360*2*M_PI)*VW);
      ps->particles[i].z = SMOKE_HEIGHT;
    }
    ps->particles[i].xspeed = 
      ((SMOKE_PULL) * (-1.0) *
      (float)sin(((double)game->vehicle[veh].orientation)/360*2*M_PI))
      + randomXspeed();
    ps->particles[i].yspeed = 
      ((SMOKE_PULL)* 
      (float)cos(((double)game->vehicle[veh].orientation)/360*2*M_PI)) 
      + randomYspeed();
    ps->particles[i].zspeed = randomZspeed();
    ps->particles[i].energy = 1.0;
    ps->particles[i].fade = randomFade();
  }
}

void ResetSmokeSystem(int veh, int right) {
  ParticleSystem * ps;
  int i;
 
  ps = particleManager->particleSystems[smokeSystem[right][veh]];

  ps->active = 1;
  ps->xpull = 0;
  ps->ypull = 0;
  ps->zpull = ZPULL;

  ps->initXspeed = (SMOKE_PULL)* (-1.0) *
    (float)sin(((double)game->vehicle[veh].orientation)/360*2*M_PI);
  ps->initYspeed = (SMOKE_PULL)* 
    (float)cos(((double)game->vehicle[veh].orientation)/360*2*M_PI);

  //ps->initXspeed = 0;
  //ps->initYspeed = SMOKE_PULL;
  ps->initZspeed = 0;

  // right exhaust or left exhaust
  // different init positions for particles
  if(right) {
    ps->initX = game->vehicle[veh].x + 
      ((float)sin(((double)game->vehicle[veh].orientation)/360*2*M_PI)*VL)+
      ((float)cos(((double)game->vehicle[veh].orientation)/360*2*M_PI)*VW);
    ps->initY = game->vehicle[veh].y -
      ((float)cos(((double)game->vehicle[veh].orientation)/360*2*M_PI)*VL)+
      ((float)sin(((double)game->vehicle[veh].orientation)/360*2*M_PI)*VW);
    ps->initZ = SMOKE_HEIGHT;
  } else {
    ps->initX = game->vehicle[veh].x + 
      ((float)sin(((double)game->vehicle[veh].orientation)/360*2*M_PI)*VL)-
      ((float)cos(((double)game->vehicle[veh].orientation)/360*2*M_PI)*VW);
    ps->initY = game->vehicle[veh].y -
      ((float)cos(((double)game->vehicle[veh].orientation)/360*2*M_PI)*VL)-
      ((float)sin(((double)game->vehicle[veh].orientation)/360*2*M_PI)*VW);
    ps->initZ = SMOKE_HEIGHT;
  }

  ps->initEnergy = 1;
  ps->size = 0.5;

  // particle vars
  for(i = 0; i < MAX_PARTICLE; i++) {
    if(right) {
      ps->particles[i].x = game->vehicle[veh].x +
        ((float)sin(((double)game->vehicle[veh].orientation)/360*2*M_PI)*VL)+
        ((float)cos(((double)game->vehicle[veh].orientation)/360*2*M_PI)*VW);
      ps->particles[i].y = game->vehicle[veh].y -
        ((float)cos(((double)game->vehicle[veh].orientation)/360*2*M_PI)*VL)+
        ((float)sin(((double)game->vehicle[veh].orientation)/360*2*M_PI)*VW);
      ps->particles[i].z = SMOKE_HEIGHT;
    } else {
      ps->particles[i].x = game->vehicle[veh].x +
        ((float)sin(((double)game->vehicle[veh].orientation)/360*2*M_PI)*VL)-
        ((float)cos(((double)game->vehicle[veh].orientation)/360*2*M_PI)*VW);
      ps->particles[i].y = game->vehicle[veh].y -
        ((float)cos(((double)game->vehicle[veh].orientation)/360*2*M_PI)*VL)-
        ((float)sin(((double)game->vehicle[veh].orientation)/360*2*M_PI)*VW);
      ps->particles[i].z = SMOKE_HEIGHT;
    }
    ps->particles[i].xspeed = 
      ((SMOKE_PULL) * (-1.0) *
      (float)sin(((double)game->vehicle[veh].orientation)/360*2*M_PI))
      + randomXspeed();
    ps->particles[i].yspeed = 
      ((SMOKE_PULL)* 
      (float)cos(((double)game->vehicle[veh].orientation)/360*2*M_PI)) 
      + randomYspeed();
    //ps->particles[i].xspeed = randomXspeed();
    //ps->particles[i].yspeed = SMOKE_PULL + randomYspeed();
    ps->particles[i].zspeed = randomZspeed();
    ps->particles[i].energy = 1.0;
    ps->particles[i].fade = randomFade();
  }
}

// update smoke system based on vehcile variables
void UpdateSmokeSystem(int veh, int right) {
  ParticleSystem * ps;

  ps = particleManager->particleSystems[smokeSystem[right][veh]];
  if(right) {
    ps->initX = game->vehicle[veh].x + 
      ((float)sin(((double)game->vehicle[veh].orientation)/360*2*M_PI)*VL)+
      ((float)cos(((double)game->vehicle[veh].orientation)/360*2*M_PI)*VW);
    ps->initY = game->vehicle[veh].y -
      ((float)cos(((double)game->vehicle[veh].orientation)/360*2*M_PI)*VL)+
      ((float)sin(((double)game->vehicle[veh].orientation)/360*2*M_PI)*VW);
    ps->initZ = SMOKE_HEIGHT;
  } else {
    ps->initX = game->vehicle[veh].x + 
      ((float)sin(((double)game->vehicle[veh].orientation)/360*2*M_PI)*VL)-
      ((float)cos(((double)game->vehicle[veh].orientation)/360*2*M_PI)*VW);
    ps->initY = game->vehicle[veh].y -
      ((float)cos(((double)game->vehicle[veh].orientation)/360*2*M_PI)*VL)-
      ((float)sin(((double)game->vehicle[veh].orientation)/360*2*M_PI)*VW);
    ps->initZ = SMOKE_HEIGHT;
  }

  ps->initXspeed = (game->vehicle[veh].velocity + SMOKE_PULL)* (-1.0) *
    (float)sin(((double)game->vehicle[veh].orientation)/360*2*M_PI);
  ps->initYspeed = (game->vehicle[veh].velocity + SMOKE_PULL)* 
    (float)cos(((double)game->vehicle[veh].orientation)/360*2*M_PI);
  ps->initZspeed = 0;
}
