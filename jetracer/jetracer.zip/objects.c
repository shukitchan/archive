/* objects.c
 * This file implements objects.h
 */

#include "objects.h"
#include "random.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include "ai.h"

//global var
Game* game;

// init the game
void InitGame() {
  int i, j;
  int locationBoolean;
  double theta;

  free(game);
  game = (Game *)malloc(sizeof(Game));
  game->state = GAME_STATE_START;
  game->mode = GAME_MODE_SINGLE;
  game->cameraMode = CAMERA_MODE_OVER;

  // pole init
  game->numPole = NUM_OF_POLE;
  game->activePole[SELF] = 0;
  game->activePole[ENEMY] = 0;
  for(i = 0; i < game->numPole; i++) {
    game->poles[i].x = randomInt(PLAIN_WIDTH - (2*POLE_RADIUS)) + POLE_RADIUS;
    game->poles[i].y = randomInt(PLAIN_HEIGHT - (2*POLE_RADIUS)) + POLE_RADIUS;
  }

  // vehicle init
  for(i = 0; i < NUM_OF_VEH; i++) {
    game->vehicleConfig[i].radius = VEH_RADIUS;
    game->vehicleConfig[i].brakeForce = BRAKE_FORCE;
    game->vehicleConfig[i].accelForce = ACCEL_FORCE;
    game->vehicleConfig[i].deltaTheta = DELTA_THETA;
    // TBD
    for(;;) {
      game->vehicle[i].x = randomInt(PLAIN_WIDTH - (2*VEH_RADIUS)) + VEH_RADIUS;
      game->vehicle[i].y = randomInt(PLAIN_HEIGHT - (2*VEH_RADIUS)) + VEH_RADIUS;
      game->vehicle[i].orientation = randomInt(360);
      locationBoolean = TRUE;
      for(j = 0; j < NUM_OF_POLE; j++) {
        if((game->vehicle[i].x < (game->poles[j].x + POLE_RADIUS)) && 
           (game->vehicle[i].x > (game->poles[j].x - POLE_RADIUS)) &&
           (game->vehicle[i].y < (game->poles[j].y + POLE_RADIUS)) &&
           (game->vehicle[i].y > (game->poles[j].y - POLE_RADIUS))) {
          locationBoolean = FALSE;
        }
      }
    
      if(i == ENEMY) {
        if((game->vehicle[i].x < (game->vehicle[1-i].x + VEH_RADIUS)) && 
           (game->vehicle[i].x > (game->vehicle[1-i].x - VEH_RADIUS)) &&
           (game->vehicle[i].y < (game->vehicle[1-i].y + VEH_RADIUS)) &&
           (game->vehicle[i].y > (game->vehicle[1-i].y - VEH_RADIUS))) {
          locationBoolean = FALSE;
        }
      }

      if(locationBoolean) {
        break;
      }
    }


    game->vehicle[i].velocity = 0;
    game->vehicle[i].controlFlag[UP] = OFF;
    game->vehicle[i].controlFlag[DOWN]= OFF;
    game->vehicle[i].controlFlag[LEFT] = OFF;
    game->vehicle[i].controlFlag[RIGHT] = OFF;
    game->vehicle[i].shield = OFF;
  }

  // camera init
  theta = ((double)(-1.0 * game->vehicle[SELF].orientation))/360.0 * 2.0 * M_PI;
  game->camera.x = game->vehicle[SELF].x + 
                   (((float) sin(-1.0 * theta)) * CAMERA_DISTANCE);    
  game->camera.y = game->vehicle[SELF].y - 
                   (((float) cos(-1.0 * theta)) * CAMERA_DISTANCE);
}

// update vehicle parameters : velocity and orientation
// based on control keys
void UpdateParameters(void) {
  int i;
  float oldv;
  if(game->state == GAME_STATE_RUNNING) {
    for(i = 0; i < NUM_OF_VEH; i++) {
      if(game->vehicle[i].controlFlag[UP]) {
        game->vehicle[i].shield = OFF;
        game->vehicle[i].velocity += game->vehicleConfig[i].accelForce;
        if(game->vehicle[i].velocity > MAX_SPEED) {
          game->vehicle[i].velocity = MAX_SPEED;
        }
      }
   
      if(game->vehicle[i].controlFlag[DOWN]) {
        game->vehicle[i].velocity -= game->vehicleConfig[i].brakeForce;
        if(game->vehicle[i].velocity < 0) {
          game->vehicle[i].velocity = 0;
        }
      }

      if(game->vehicle[i].controlFlag[LEFT]) {
        game->vehicle[i].orientation += game->vehicleConfig[i].deltaTheta;
        if(game->vehicle[i].orientation >= 360) {
          game->vehicle[i].orientation = 360 - game->vehicle[i].orientation;
        }
      }

      if(game->vehicle[i].controlFlag[RIGHT]) {
        game->vehicle[i].orientation -= game->vehicleConfig[i].deltaTheta;
        if(game->vehicle[i].orientation < 0) {
          game->vehicle[i].orientation = 360 + game->vehicle[i].orientation;
        }
      }
    }
  }
}

// control keys
void ControlChange(int control, int state, int veh) {
  if(game->state == GAME_STATE_RUNNING) {
    game->vehicle[veh].controlFlag[control] = state;
  }
}

// update vehicle position
void UpdatePosition(float dt) {
  double self_theta;
  double camera_theta;
  double theta;
  double oldx, oldy;
  int i,j;

  self_theta = ((double)(-1.0 * game->vehicle[SELF].orientation))/360.0 * 2.0 * M_PI;
  camera_theta = ((double)(-1.0 * game->vehicle[ENEMY].orientation))/360.0 * 2.0 * M_PI;

  if(game->state == GAME_STATE_RUNNING) {
    for(i = 0; i < NUM_OF_VEH; i++) {
      oldx = game->vehicle[i].x;
      oldy = game->vehicle[i].y;

      if(i == SELF) {
        theta = self_theta;
      } else {
        theta = camera_theta;
      }
      game->vehicle[i].x += ((float) sin(theta)) * game->vehicle[i].velocity * dt;
      if(game->vehicle[i].x > (PLAIN_WIDTH - game->vehicleConfig[i].radius)) {
        game->vehicle[i].x = oldx;
        //game->vehicle[i].x = PLAIN_WIDTH - game->vehicleConfig[i].radius;
        game->vehicle[i].velocity = 0;
        game->vehicle[i].shield = ON;
      }
      if(game->vehicle[i].x < (game->vehicleConfig[i].radius)) {
        game->vehicle[i].x = oldx;
        //game->vehicle[i].x = game->vehicleConfig[i].radius;
        game->vehicle[i].velocity = 0;
        game->vehicle[i].shield = ON;
      }

      game->vehicle[i].y += ((float) cos(theta)) * game->vehicle[i].velocity * dt;
      if(game->vehicle[i].y > (PLAIN_HEIGHT - game->vehicleConfig[i].radius)) {
        game->vehicle[i].y = oldy;
        //game->vehicle[i].y = PLAIN_HEIGHT - game->vehicleConfig[i].radius;
        game->vehicle[i].velocity = 0;
        game->vehicle[i].shield = ON;
      }
      if(game->vehicle[i].y < (game->vehicleConfig[i].radius)) {
        game->vehicle[i].y = oldy;
        //game->vehicle[i].y = game->vehicleConfig[i].radius;
        game->vehicle[i].velocity = 0;
        game->vehicle[i].shield = ON;
      }      

      /*
      for(j = 0; j < NUM_OF_POLE; j++) {
        if((game->vehicle[i].x < (game->poles[j].x + POLE_RADIUS)) && 
           (game->vehicle[i].x > (game->poles[j].x - POLE_RADIUS)) &&
           (game->vehicle[i].y < (game->poles[j].y + POLE_RADIUS)) &&
           (game->vehicle[i].y > (game->poles[j].y - POLE_RADIUS))) {
          game->vehicle[i].x = oldx;
          game->vehicle[i].y = oldy;
          game->vehicle[i].velocity = 0;
          game->vehicle[i].shield = ON;
        }
      }
    
      if(game->mode == GAME_MODE_DOUBLE) {
        if((game->vehicle[i].x < (game->vehicle[1-i].x + (1.5*VEH_RADIUS))) && 
           (game->vehicle[i].x > (game->vehicle[1-i].x - (1.5*VEH_RADIUS))) &&
           (game->vehicle[i].y < (game->vehicle[1-i].y + (1.5*VEH_RADIUS))) &&
           (game->vehicle[i].y > (game->vehicle[1-i].y - (1.5*VEH_RADIUS)))) {
          game->vehicle[i].x = oldx;
          game->vehicle[i].y = oldy;
          game->vehicle[i].velocity = 0;
          game->vehicle[1-i].velocity = 0;
          game->vehicle[i].shield = ON;
          game->vehicle[1-i].shield = ON;
        }
      }
      */
    }
  }

  // update camera position based on vehicle position
  theta = self_theta;
  if(game->cameraMode == CAMERA_MODE_OVER) {
    game->camera.x = game->vehicle[SELF].x + 
                     (((float) sin(-1.0 * theta)) * CAMERA_DISTANCE);    
    game->camera.y = game->vehicle[SELF].y - 
                     (((float) cos(-1.0 * theta)) * CAMERA_DISTANCE);
  } else {
    game->camera.x = game->vehicle[SELF].x - 
                     (((float) sin(-1.0 * theta)) * CAMERA_SHORT_DISTANCE);
    game->camera.y = game->vehicle[SELF].y + 
                     (((float) cos(-1.0 * theta)) * CAMERA_SHORT_DISTANCE);
  }
}

// if vehicle is closed to a pole, change the active pole to next
void CheckProximity(void) {
  double distance;
  int i, j;

  if(game->state == GAME_STATE_RUNNING) {
    for(i = 0; i < NUM_OF_VEH; i++) {
      distance = (double)
                 (((game->vehicle[i].x - game->poles[game->activePole[i]].x) *
                   (game->vehicle[i].x - game->poles[game->activePole[i]].x)) +
                  ((game->vehicle[i].y - game->poles[game->activePole[i]].y) *
                   (game->vehicle[i].y - game->poles[game->activePole[i]].y)));
      distance = sqrt(distance);
      // pass a pole
      if(distance < PROXIMITY_DISTANCE) {
        game->activePole[i]++;
      }
    }

    // all poles are passed. end game
    if(game->activePole[SELF] >= game->numPole) {
      // you win
      setGameState(GAME_STATE_END);
      printf("Game Over. You won ! \n");      
    } else if(game->activePole[ENEMY] >= game->numPole) {
      // you lose
      setGameState(GAME_STATE_END);
      printf("Game Over. You lose ! \n");      
    }

    if(game->activePole[SELF] >= game->numPole) {
      game->activePole[SELF] = game->numPole - 1;
    } 
    if(game->activePole[ENEMY] >= game->numPole) {
      game->activePole[ENEMY] = game->numPole - 1;
    } 
  }
}

// update game parameters
void UpdateGame(float dt) {
  if((getGameMode() == GAME_MODE_DOUBLE) &&
     (getGameState() == GAME_STATE_RUNNING)) {
    PredictEnemyAction();
  }

  UpdateParameters();
  UpdatePosition(dt);
  CheckProximity();
}

// functions for setting game parameters
void setGameState(int state) {
  // cannot change state if game is ended
  if(game->state != GAME_STATE_END) {
    game->state = state;
  }
}

int getGameState(void) {
  return game->state;
}

void setGameMode(int mode) {
  // cannot set 1 player or 2 player unless at the beginning of game
  if(game->state == GAME_STATE_START) {
    game->mode = mode;
    if(mode == GAME_MODE_SINGLE) { 
      printf("1 Player Mode\n");
    } else {
      printf("2 Player Mode\n");
    }
  }
}

int getGameMode(void) {
  return game->mode;
}

void setCameraMode(int mode) {
  game->cameraMode = mode;
}

int getCameraMode(void) {
  return game->cameraMode;
}
