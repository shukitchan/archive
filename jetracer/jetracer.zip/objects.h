/* objects.h
 * Defines the data structures and objects
 */

#ifndef _OBJECTS_H
#define _OBJECTS_H

#define ON 1
#define OFF 0

#define TRUE 1
#define FALSE 0

#define SELF 0
#define ENEMY 1

#define NUM_OF_VEH 2
#define NUM_OF_CONTROL 4

#define UP 0
#define DOWN 1
#define LEFT 2
#define RIGHT 3

#define PLAIN_WIDTH 1000
#define PLAIN_HEIGHT 1000
#define CAMERA_DISTANCE 62
#define CAMERA_SHORT_DISTANCE 8
#define CAMERA_HEIGHT 25
#define MAX_SPEED 140
#define PROXIMITY_DISTANCE 30
#define DELTA_THETA 3
#define BRAKE_FORCE 5
#define ACCEL_FORCE 5
#define VEH_RADIUS 10
#define POLE_RADIUS 10

#define GAME_STATE_START 0
#define GAME_STATE_RUNNING 1
#define GAME_STATE_END 2

#define GAME_MODE_SINGLE 0
#define GAME_MODE_DOUBLE 1

#define NUM_OF_POLE 20

#define CAMERA_MODE_OVER 0
#define CAMERA_MODE_INSIDE 1

// vehicle configuration
typedef struct {
  float deltaTheta;
  float accelForce;
  float brakeForce;
  float radius;
} VehicleConfig;

// vehicle vars
typedef struct {
  float orientation;
  float velocity;
  float x;
  float y;
  int controlFlag[NUM_OF_CONTROL];
  int shield;
} Vehicle;

// pole vars
typedef struct {
  float x;
  float y;
} Pole;

// camera vars
typedef struct {
  float x;
  float y;
} Camera;

// game setup
typedef struct {
  Vehicle vehicle[NUM_OF_VEH];
  VehicleConfig vehicleConfig[NUM_OF_VEH];

  Pole poles[NUM_OF_POLE];
  int activePole[NUM_OF_VEH];
  int numPole;

  Camera camera;

  int mode;
  int state;
  int cameraMode;
} Game;

extern Game* game;

void InitGame();
void UpdateGame(float dt);

void ControlChange(int control, int state, int veh);

void setGameState(int state);
int getGameState(void);

void setGameMode(int mode);
int getGameMode(void);

void setCameraMode(int mode);
int getCameraMode(void);

#endif
