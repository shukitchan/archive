/* ai.h
 * Defines the routine for determining enemy vehicle action
 */

#ifndef _AI_H
#define _AI_H

void PredictEnemyAction(void);

#endif
