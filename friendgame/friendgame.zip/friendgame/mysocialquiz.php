<?php

   // Include the YSP PHP SDK to access the library.
   // Depending on where you installed the SDK,
   // you may need to change the path of Yahoo.inc.
   include_once("lib/Yahoo.inc");
   
   // Define constants to store your API Key (Consumer Key) and 
   // Shared Secret (Consumer Secret).
   define("API_KEY","dj0yJmk9V2c0ZXExbFpCSHBBJmQ9WVdrOU5ETTBhbVpETjJjbWNHbzlPVEl6TXprM05EVXkmcz1jb25zdW1lcnNlY3JldCZ4PTdl");
   define("SHARED_SECRET","351618bdc28cb38057c1eb80d7cbf559234f574d");   

   // Enable debugging. Errors are reported to Web server's error log.
   //YahooLogger::setDebug(true);

   // Initializes session and redirects user to Yahoo! to sign in and 
   // then authorize app
   $yahoo_session = YahooSession::requireSession(API_KEY, SHARED_SECRET); 
   if ($yahoo_session == NULL) {
       fatal_error("yahoo_session");
   }

   // Get the YahooUser object that represents the person running this app.
   $yahoo_user = $yahoo_session->getSessionedUser();  
   if ($yahoo_user == NULL) {
      fatal_error("yahoo_user");
   }

   // profile
   $user_profile = $yahoo_user->getProfile();  
   if ($user_profile == NULL) {
      fatal_error("user_profile");
   }

$cguid = $_REQUEST['cguid'];
$chosen_uid = substr($cguid, 0, 26);
$attribute = substr($cguid,26, 1);
$value = substr($cguid, 27);

        $chosen_user = $yahoo_session->getUser($chosen_uid);
        $chosen_user_profile = $chosen_user->getProfile();

$chosen_value = get_value($chosen_user_profile, $attribute); 
$chosen_value = urlencode($chosen_value);

if($chosen_value == $value)
  {
    $text = <<<TEXT
<div style="margin: 5px; width: 98%;">
    <div style="overflow: hidden; height: 50px; width: 100%; float: left;">
      <yml:a view="YahooFullView">
        <img style="border: 0px none;" width="210" heigh="48" src="http://aagqx854.yahoo.joyent.us/friendgame/friendgame.png"/>
      </yml:a>
    </div>
    <div style="overflow: hidden; height: 150px; width: 100%; float: left;">
        <div style="padding: 5px; font-weight: bold;">Correct Answer! You know this guy pretty well. Must be your buddy. Wanna ping him now?</div>
        <div style="padding: 5px;"><yml:profile-pic uid="$chosen_uid" width="48" /> <yml:name uid="$chosen_uid" linked="true" capitalize="true" />
        </div>
        <div style="padding: 5px; font-weight: bold;">Or play the <yml:a view="YahooFullView">Friend Game</yml:a> again!</div>
    </div>
</div>
TEXT;
    $yahoo_user->setSmallView($text);
    echo $text;
    exit;    
  }
else
  {
    $text = <<<TEXT
<div style="margin: 5px; width: 98%;">
    <div style="overflow: hidden; height: 50px; width: 100%; float: left;">
      <yml:a view="YahooFullView">
        <img style="border: 0px none;" width="210" heigh="48" src="http://aagqx854.yahoo.joyent.us/friendgame/friendgame.png"/>
      </yml:a>
    </div>
    <div style="overflow: hidden; height: 150px; width: 100%; float: left;">
        <div style="padding: 5px; font-weight: bold;">That's wrong. You two might not be on the same page. Or he/she is not letting you know his/her stuff. Why don't you ping her?</div>
        <div style="padding: 5px;"><yml:profile-pic uid="$chosen_uid" width="48" /> <yml:name uid="$chosen_uid" linked="true" capitalize="true" />
        </div>
        <div style="padding: 5px; font-weight: bold;">Or play the <yml:a view="YahooFullView">Friend Game</yml:a> again!</div>
    </div>
</div>
TEXT;
    $yahoo_user->setSmallView($text);
    echo $text;
    exit;    
  }
   
function get_value($connect, $a)
{
  $value = '';
  if($a == 0 && isset($connect->interests[0]->declaredInterests[0]))
    {
      $value = $connect->interests[0]->declaredInterests[0];
    }
  if($a == 1 && isset($connect->interests[1]->declaredInterests[0]))
    {
      $value = $connect->interests[1]->declaredInterests[0];
    }
  if($a == 2 && isset($connect->interests[2]->declaredInterests[0]))
    {
      $value = $connect->interests[2]->declaredInterests[0];
    }
  if($a == 3 && isset($connect->interests[3]->declaredInterests[0]))
    {
      $value = $connect->interests[3]->declaredInterests[0];
    }
  if($a == 4 && isset($connect->interests[4]->declaredInterests[0]))
    {
      $value = $connect->interests[4]->declaredInterests[0];
    }
  if($a == 5 && isset($connect->interests[5]->declaredInterests[0]))
    {
      $value = $connect->interests[5]->declaredInterests[0];
    }
  if($a == 6 && isset($connect->interests[6]->declaredInterests[0]))
    {
      $value = $connect->interests[6]->declaredInterests[0];
    }
  if($a == 7 && isset($connect->relationshipStatus))
    {
      $value = $connect->relationshipStatus;
    }
  if($a == 8 && isset($connect->schools[0]->schoolName))
    {
      $value = $connect->schools[0]->schoolName;
    }
  if($a ==9 && isset($connect->works[0]->workName))
    {
      $value = $connect->works[0]->workName;
    }
  return $value;  
}

   function fatal_error($object_name) {
      // Print error message and and then exit the script.
      print ("<br />");
      print ("Error detected in mysocial.php: Cannot get $object_name.");
      print ("<br />");
      print ("In the Application Editor, verify that the Permissions are set correctly.");
      print ("<br />");
      print ("Also, make sure that the Consumer Key and Shared Secret in the source code are correct.");
      exit;
   }
?>

