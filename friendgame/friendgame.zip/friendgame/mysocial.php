<?php

   // Include the YSP PHP SDK to access the library.
   // Depending on where you installed the SDK,
   // you may need to change the path of Yahoo.inc.
   include_once("lib/Yahoo.inc");
   
   // Define constants to store your API Key (Consumer Key) and 
   // Shared Secret (Consumer Secret).
   define("API_KEY","dj0yJmk9V2c0ZXExbFpCSHBBJmQ9WVdrOU5ETTBhbVpETjJjbWNHbzlPVEl6TXprM05EVXkmcz1jb25zdW1lcnNlY3JldCZ4PTdl");
   define("SHARED_SECRET","351618bdc28cb38057c1eb80d7cbf559234f574d");   

   // Enable debugging. Errors are reported to Web server's error log.
   YahooLogger::setDebug(true);
   
   // Initializes session and redirects user to Yahoo! to sign in and 
   // then authorize app
   $yahoo_session = YahooSession::requireSession(API_KEY, SHARED_SECRET); 
   if ($yahoo_session == NULL) {
       fatal_error("yahoo_session");
   }
   // Get the YahooUser object that represents the person running this app.
   $yahoo_user = $yahoo_session->getSessionedUser();  
   if ($yahoo_user == NULL) {
      fatal_error("yahoo_user");
   }

   // profile
   $user_profile = $yahoo_user->getProfile();  
   if ($user_profile == NULL) {
      fatal_error("user_profile");
   }

   // Add an update to the user's update list.

   // Assign a unique values to the variable suid. 
   $suid = sprintf("%d%s",time(),$user_profile->guid);  
      
   // Create a title and link to the event.  
   $title = "is playing the Awesome Friend Game. Try it out.";  
   $link_back_to_event = "http://apps.yahoo.com/-434jfC7g";  
      
   // Pass the SUID, title and link to event to method insertUpdate.  
   $yahoo_user->insertUpdate($suid, $title, $link_back_to_event);  

   // get total connections
$start = 0; 
$count = 10;
$num = 0;
$connections = $yahoo_user->getConnections($start, $count, $num);

if($num < 10)
  {
    $text = <<<TEXT
<div style="margin: 5px; width: 98%;">
    <div style="overflow: hidden; height: 50px; width: 100%; float: left;">
      <yml:a view="YahooFullView">
        <img style="border: 0px none;" height="48" width="210" src="http://aagqx854.yahoo.joyent.us/friendgame/friendgame.png"/>
      </yml:a>
    </div>
    <div style="overflow: hidden; height: 150px; width: 100%; float: left;">
        <div style="padding: 5px; font-weight: bold;">You need at least 10 connections to play the game. Go to your profile and invite more friends to connect with you.</div>
        <div style="padding: 5px;"><yml:profile-pic width="48" /> <yml:name linked="true" capitalize="true" /></div>
    </div>
</div>
TEXT;
    $yahoo_user->setSmallView($text);
    echo $text;
    exit;
  }

// generate random connect
$total = 5;
$rand = array();
while(count($rand) < $total)
  {
    $r= mt_rand(0, $num-1);
    if(!in_array($r, $rand))
      {
        $rand[] = $r;
      }
  }

// get connects info
$connects = array();
$count = 1;
foreach($rand as $r)
{
    $connections = $yahoo_user->getConnections($r, $count, $num);
    foreach($connections as $connection)
      {
        $connect_user = $yahoo_session->getUser($connection->guid);
        $connect_user_profile = $connect_user->getProfile();
        $connects[] = $connect_user_profile;
      }
}

// find connects stuff
$subjects = array();
$index = 0;
foreach($connects as $connect)
{
    if(isset($connect->interests[0]->declaredInterests[0]) && $connect->interests[0]->declaredInterests[0])
      {
        $subjects[] = $index * 10 + 0;
      }
    if(isset($connect->interests[1]->declaredInterests[0]) && $connect->interests[1]->declaredInterests[0])
      {
        $subjects[] = $index * 10 + 1;
      }
    if(isset($connect->interests[2]->declaredInterests[0]) && $connect->interests[2]->declaredInterests[0])
      {
        $subjects[] = $index * 10 + 2;
      }
    if(isset($connect->interests[3]->declaredInterests[0]) && $connect->interests[3]->declaredInterests[0])
      {
        $subjects[] = $index * 10 + 3;
      }
    if(isset($connect->interests[4]->declaredInterests[0]) && $connect->interests[4]->declaredInterests[0])
      {
        $subjects[] = $index * 10 + 4;
      }
    if(isset($connect->interests[5]->declaredInterests[0]) && $connect->interests[5]->declaredInterests[0])
      {
        $subjects[] = $index * 10 + 5;
      }
    if(isset($connect->interests[6]->declaredInterests[0]) && $connect->interests[6]->declaredInterests[0])
      {
        $subjects[] = $index * 10 + 6;
      }
    if(isset($connect->relationshipStatus) && $connect->relationshipStatus)
      {
        $subjects[] = $index * 10 + 7;
      }
    if(property_exists($connect, "schools"))
      { 
        $subjects[] = $index * 10 + 8;
      }
    if(property_exists($connect, "works"))
      {
        $subjects[] = $index * 10 + 9;
      }
    $index++;
}

if(count($subjects) <= 0)
  {
    $text = <<<TEXT
<div style="margin: 5px; width: 98%;">
    <div style="overflow: hidden; height: 50px; width: 660px; float: left;">
      <yml:a view="YahooFullView">
        <img style="border: 0px none;" width="210" heigh="48" src="http://aagqx854.yahoo.joyent.us/friendgame/friendgame.png"/>
      </yml:a>
    </div>
    <div style="overflow: hidden; height: 80px; width: 660px; float: left;">
        <div style="padding: 5px; font-weight: bold;">It seems your connects are shy to share their information. Why don't you ask them to share more?</div>
    </div>
    <style>
      .photo_container {width: 650px;background:pink;}
      .photo_container li{display: block; width:120px; height:160px; float:left; border:1px;}
      .photo_container li img {margin-bottom: 10px;}
      .photo_container li b {font-weight:normal;display:block;width:70px;height:20px;margin:0 15px;}
    </style>
<div class="photo_container">
<ul>
TEXT;
    
    $line = '';
    foreach($connects as $connect)
      {
        $src = $connect->image->imageUrl;
        $uid = $connect->guid;
        $height = (int)floor($connect->image->height/2);
        $width = (int)floor($connect->image->width/2);
        $line .= <<<TEXT
	  <li><img src="$src" height="$height" width="$width" /><b><yml:name uid="$uid" linked="true"/></b></li>
TEXT;
      }

    $finaltext = <<<TEXT
    <div style="overflow: hidden; height: 150px; width: 100%; float: left;">
        <div style="padding: 5px; font-weight: bold;">Or you can play the <yml:a view="YahooFullView">Friend Game</yml:a> again!</div>
    </div>
TEXT;

    $full = $text.$line.'</ul></div>'.$finaltext.'</div>';
    echo $full;
    exit;    
  }
else
  {
    $target = mt_rand(0, count($subjects)-1);
    $a = $subjects[$target] % 10;
    $c = (($subjects[$target] - $a) / 10);

    $value = '';
    $question = get_question($connects, $c, $a, $value);
    $value = urlencode($value);

    $text = <<<TEXT
<div style="margin: 5px; width: 98%;">
    <div style="overflow: hidden; height: 50px; width: 660px; float: left;">
      <yml:a view="YahooFullView">
        <img style="border: 0px none;" width="210" heigh="48" src="http://aagqx854.yahoo.joyent.us/friendgame/friendgame.png"/>
      </yml:a>
    </div>
    <div style="overflow: hidden; height: 80px; width: 660px; float: left;">
        <div style="padding: 5px; font-weight: bold;">$question ... </div>
    </div>
    <style>
      .photo_container {width: 650px;background:pink;}
      .photo_container li{display: block; width:120px; height:160px; float:left; border:1px;}
      .photo_container li img {margin-bottom: 10px;}
      .photo_container li b {font-weight:normal;display:block;width:70px;height:20px;margin:0 15px;}
    </style>
<div class="photo_container">
<ul>
TEXT;
    
    $line = '';
    foreach($connects as $connect)
      {
        $src = $connect->image->imageUrl;
        $uid = $connect->guid;
        $height = (int)floor($connect->image->height/2);
        $width = (int)floor($connect->image->width/2);
        $line .= <<<TEXT
	  <li><yml:a view="YahooFullView" params="mysocialquiz.php?cguid={$uid}{$a}{$value}"><img src="$src" height="$height" width="$width" /></a><b><yml:name uid="$uid" /></b></li>
TEXT;
      }

    echo $text.$line.'</ul></div></div>';
    exit;
  }
  
function get_question($connects, $c, $a, &$value)
{
  $connect = $connects[$c];
  if($a == 0)
    {
      $value = $connect->interests[0]->declaredInterests[0];
      return 'Whose favorite hobbies are "'.$connect->interests[0]->declaredInterests[0].'"?';
    }
  if($a == 1)
    {
      $value = $connect->interests[1]->declaredInterests[0];
      return 'Whose favorite music is "'.$connect->interests[1]->declaredInterests[0].'"?';
    }
  if($a == 2)
    {
      $value = $connect->interests[2]->declaredInterests[0];
      return 'Whose favorite movies are "'.$connect->interests[2]->declaredInterests[0].'"?';
    }
  if($a == 3)
    {
      $value = $connect->interests[3]->declaredInterests[0];
      return 'Whose favorite books are "'.$connect->interests[3]->declaredInterests[0].'"?';
    }
  if($a == 4)
    {
      $value = $connect->interests[4]->declaredInterests[0];
      return 'Whose favorite quotes are "'.$connect->interests[4]->declaredInterests[0].'"?';
    }
  if($a == 5)
    {
      $value = $connect->interests[5]->declaredInterests[0];
      return 'Whose favorite food is "'.$connect->interests[5]->declaredInterests[0].'"?';
    }
  if($a == 6)
    {
      $value = $connect->interests[6]->declaredInterests[0];
      return 'Whose favorite places are "'.$connect->interests[6]->declaredInterests[0].'"?';
    }
  if($a == 7)
    {
      $value = $connect->relationshipStatus;
      return 'Who specifies that their relationship status is "'.$connect->relationshipStatus.'"?';
    }
  if($a == 8)
    {
      $value = $connect->schools[0]->schoolName;
      return 'Who attended or is attending '.$connect->schools[0]->schoolName.'?';
    }
  if($a ==9)
    {
      $value = $connect->works[0]->workName;
      return 'Who worked or is working for '.$connect->works[0]->workName.'? ';
    }
  return '';  
}

   function fatal_error($object_name) {
      // Print error message and and then exit the script.
      print ("<br />");
      print ("Error detected in mysocial.php: Cannot get $object_name.");
      print ("<br />");
      print ("In the Application Editor, verify that the Permissions are set correctly.");
      print ("<br />");
      print ("Also, make sure that the Consumer Key and Shared Secret in the source code are correct.");
      exit;
   }
?>

