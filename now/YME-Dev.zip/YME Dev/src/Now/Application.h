#include <objsafe.h>

#if !defined(AFX_APPLICATION_H__9270A14B_4F17_4750_8672_FF605F85A146__INCLUDED_)
#define AFX_APPLICATION_H__9270A14B_4F17_4750_8672_FF605F85A146__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Application.h : header file
//



/////////////////////////////////////////////////////////////////////////////
// CApplication command target

class CApplication : public CCmdTarget
{
	DECLARE_DYNCREATE(CApplication)

	CApplication();           // protected constructor used by dynamic creation

// Attributes
public:

	BEGIN_INTERFACE_PART(ObjectSafety, IObjectSafety)
		STDMETHOD(GetInterfaceSafetyOptions)(REFIID riid, DWORD __RPC_FAR *pdwSupportedOptions, DWORD __RPC_FAR *pdwEnabledOptions);
		STDMETHOD(SetInterfaceSafetyOptions)(REFIID riid, DWORD dwOptionSetMask, DWORD dwEnabledOptions);
 	END_INTERFACE_PART(ObjectSafety)

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CApplication)
	public:
	virtual void OnFinalRelease();
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CApplication();

	// Generated message map functions
	//{{AFX_MSG(CApplication)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
	DECLARE_OLECREATE(CApplication)

	// Generated OLE dispatch map functions
	//{{AFX_DISPATCH(CApplication)
	afx_msg VARIANT Name();
	//}}AFX_DISPATCH
	DECLARE_DISPATCH_MAP()
	DECLARE_INTERFACE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_APPLICATION_H__9270A14B_4F17_4750_8672_FF605F85A146__INCLUDED_)
