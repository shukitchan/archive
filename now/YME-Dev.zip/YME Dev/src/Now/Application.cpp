// Application.cpp : implementation file
//

#include "stdafx.h"
#include "Now.h"
#include "Application.h"
#include "winable.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CApplication

IMPLEMENT_DYNCREATE(CApplication, CCmdTarget)

CApplication::CApplication()
{
	EnableAutomation();
	
	// To keep the application running as long as an OLE automation 
	//	object is active, the constructor calls AfxOleLockApp.
	
	AfxOleLockApp();
}

CApplication::~CApplication()
{
	// To terminate the application when all objects created with
	// 	with OLE automation, the destructor calls AfxOleUnlockApp.
	
	AfxOleUnlockApp();
}


void CApplication::OnFinalRelease()
{
	// When the last reference for an automation object is released
	// OnFinalRelease is called.  The base class will automatically
	// deletes the object.  Add additional cleanup required for your
	// object before calling the base class.

	CCmdTarget::OnFinalRelease();
}


BEGIN_MESSAGE_MAP(CApplication, CCmdTarget)
	//{{AFX_MSG_MAP(CApplication)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BEGIN_DISPATCH_MAP(CApplication, CCmdTarget)
	//{{AFX_DISPATCH_MAP(CApplication)
	DISP_FUNCTION(CApplication, "Name", Name, VT_VARIANT, VTS_NONE)
	//}}AFX_DISPATCH_MAP
END_DISPATCH_MAP()

// Note: we add support for IID_IApplication to support typesafe binding
//  from VBA.  This IID must match the GUID that is attached to the 
//  dispinterface in the .ODL file.

// {B93828CD-E02A-4380-B25B-15384F333528}
static const IID IID_IApplication =
{ 0xb93828cd, 0xe02a, 0x4380, { 0xb2, 0x5b, 0x15, 0x38, 0x4f, 0x33, 0x35, 0x28 } };

BEGIN_INTERFACE_MAP(CApplication, CCmdTarget)
	INTERFACE_PART(CApplication, IID_IApplication, Dispatch)
	INTERFACE_PART(CApplication, IID_IObjectSafety, ObjectSafety)
END_INTERFACE_MAP()

// {5FE7D7C5-CDCA-4C1A-8078-3DA609054C54}
IMPLEMENT_OLECREATE(CApplication, "Now.Application", 0x5fe7d7c5, 0xcdca, 0x4c1a, 0x80, 0x78, 0x3d, 0xa6, 0x9, 0x5, 0x4c, 0x54)

/////////////////////////////////////////////////////////////////////////////
// CApplication message handlers

VARIANT CApplication::Name() 
{
	VARIANT vaResult;
	VariantInit(&vaResult);
	// TODO: Add your dispatch handler code here
    GUITHREADINFO guiThreadInfo; 
	guiThreadInfo.cbSize = sizeof(GUITHREADINFO);
	
	if(GetGUIThreadInfo(NULL, &guiThreadInfo))
	{
      TCHAR szBuf[80];
      GetWindowText(guiThreadInfo.hwndActive, szBuf, 80);
  	  return COleVariant(szBuf).Detach();
	}

	return vaResult;
}

STDMETHODIMP CApplication::XObjectSafety::GetInterfaceSafetyOptions(REFIID riid, DWORD __RPC_FAR *pdwSupportedOptions, DWORD __RPC_FAR *pdwEnabledOptions)
{
	*pdwSupportedOptions = INTERFACESAFE_FOR_UNTRUSTED_CALLER | INTERFACESAFE_FOR_UNTRUSTED_DATA;
	*pdwEnabledOptions = 0;
	return S_OK;
}

STDMETHODIMP CApplication::XObjectSafety::SetInterfaceSafetyOptions(REFIID riid, DWORD dwOptionSetMask, DWORD dwEnabledOptions)
{
	return S_OK;
}

STDMETHODIMP_(ULONG) CApplication::XObjectSafety::AddRef()
{
	METHOD_PROLOGUE_EX_(CApplication, ObjectSafety)
	return (ULONG)pThis->ExternalAddRef();
}

STDMETHODIMP_(ULONG) CApplication::XObjectSafety::Release()
{
	METHOD_PROLOGUE_EX_(CApplication, ObjectSafety)
	return (ULONG)pThis->ExternalRelease();
}

STDMETHODIMP CApplication::XObjectSafety::QueryInterface(REFIID iid, LPVOID* ppvObj)
{
	METHOD_PROLOGUE_EX_(CApplication, ObjectSafety)
	return (HRESULT)pThis->ExternalQueryInterface(&iid, ppvObj);
}